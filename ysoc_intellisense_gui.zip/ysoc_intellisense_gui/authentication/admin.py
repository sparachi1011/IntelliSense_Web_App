from django.contrib import admin
from authentication.models import app_user_info
# Register your models here.
admin.site.register(app_user_info)