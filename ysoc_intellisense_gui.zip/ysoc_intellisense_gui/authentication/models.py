from django.db import models
from django.utils import timezone
# Create your models here.


class app_user_info(models.Model):

    UserName = models.CharField(
        ("UserName"), max_length=50, primary_key=True, db_index=True)
    FirstName = models.CharField(
        ("FirstName"), max_length=50, blank=False, null=False)
    LastName = models.CharField(
        ("LastName"), max_length=50, blank=False, null=False)
    EmailID = models.EmailField(("Email@domain.com"),
                                max_length=50, null=False, blank=False)
    Password = models.CharField(("Password"), max_length=500,
                                blank=False, null=False, unique=True)
    UserJoinedDate = models.DateTimeField(auto_now_add=True)
    UserAccountActivated = models.BooleanField(
        ("UserAccountActivated"), default=False)
    UserEmailIDVerified = models.BooleanField(
        ("UserEmailIDVerified"), default=False)
    IsUserLoggedInToApp = models.BooleanField(
        ("IsUserLoggedInToApp"), default=False)

    # auto_add_now=True)  # default=timezone.now)

    # def __str__(self):
    #     return self.UserJoinedDate
