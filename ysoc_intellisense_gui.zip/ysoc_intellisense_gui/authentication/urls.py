from django.contrib import admin
from django.urls import path, include
from authentication import views

urlpatterns = [
    path('', views.home, name='home'),
    path('home', views.home, name='home'),
    # path(r'^$', views.home, name='home'),
    path('index', views.home, name='home'),
    path('signup', views.signup, name='signup'),
    path('activate/<uidb64>/<token>', views.activate, name='activate'),
    path('signin', views.signin, name='signin'),
    path('signout', views.signout, name='signout'),
    # path('delete', views.delete_session, name='delete_session')

]
handler400 = 'authentication.views.error_400_view'
handler403 = 'authentication.views.error_403_view'
handler404 = 'authentication.views.error_404_view'
handler500 = 'authentication.views.error_500_view'
