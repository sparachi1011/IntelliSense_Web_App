from ysoc_intellisense_imports import pd, pdb, logger, render, redirect, read_frame, cache_control, \
    HttpResponse, messages, EmailMessage, send_mail, settings, urlsafe_base64_decode, urlsafe_base64_encode, \
    force_str, authenticate, login, logout, login_required, handler,smtplib#,MIMEText,MIMEMultipart,formatdate,msg
from django.contrib.auth.models import User
from . tokens import generate_token
from authentication.models import app_user_info
from ysoc_intellisense_gui.info import *
from django.views.decorators.csrf import ensure_csrf_cookie

def get_user_session(request):
    try:
        # print(request)
        # pdb.set_trace()
        data_com = {"LoggedUser": request.session.get('LoggedUser'),#).capitalize(),
                    "LoggedUserEmainID": request.session.get('LoggedUserEmainID'),
                    "UserLoggedIn": False,
                    "NoDataFound": False,
                    }
        # if str(request.session.get('LoggedUser')).capitalize().strip() !='None':
        #     data_com |={"LoggedUser" :str(request.session.get('LoggedUser')).capitalize().strip(),
        #                 "LoggedUserEmainID": request.session.get('LoggedUserEmainID'),}
        # elif str(request.POST['UserName']).capitalize().strip() !='None':
        #     data_com |={"LoggedUser" :str(request.POST['UserName']).capitalize().strip(),
        #                 # "LoggedUserEmainID": request.session.get('LoggedUserEmainID'),
        #                 }
        # elif str(request.GET['UserName']).capitalize().strip() !='None':
        #     data_com |={"LoggedUser" :str(request.GET['UserName']).capitalize().strip(),
        #                 # "LoggedUserEmainID": request.session.get('LoggedUserEmainID'),
        #                 }

        # pdb.set_trace()
        if request.session.get('LoggedUser') !=None:
            ysoc_intellisense_user_info_qs = app_user_info.objects.all().filter(UserName=data_com['LoggedUser'])
            ysoc_intellisense_user_info_df = read_frame(ysoc_intellisense_user_info_qs)
            # print(ysoc_intellisense_user_info_df)
            IsUserLoggedInToApp = ysoc_intellisense_user_info_df['IsUserLoggedInToApp']
            data_com |={"UserLoggedIn" :IsUserLoggedInToApp[0],
                        "ysoc_intellisense_user_info_df" :ysoc_intellisense_user_info_df }
        # print("data_com\n",data_com)
        return data_com
    except Exception as e:
        logger.exception(
            "Error at get_user_session funtion in authentication.views as:%s", e)
        
@cache_control(no_cache=True, must_revalidate=True, no_store=True)
def home(request):
    try:
        # pdb.set_trace()
        data_com = get_user_session(request)
        # UserLoggedIn = False
        if data_com["UserLoggedIn"] and data_com["LoggedUser"] !=None:
            return render(request, "authentication/home.html", {"UserLoggedIn": data_com["UserLoggedIn"]})#UserLoggedIn})#data_com["UserLoggedIn"]})
        else:
            return redirect('signin')
    except Exception as e:
        logger.exception(
            "Error at home funtion in authentication.views as:%s", e)
        return redirect('signin')


def send_email(myuser, request):
    try:
        # Welcome Email
        # pdb.set_trace()
        # import smtplib
        # import email
        from email.mime.base import MIMEBase
        from email.mime.text import MIMEText
        from email.mime.multipart import MIMEMultipart
        from email.utils import formatdate
        # from email import encoders
        from email import message as msg

        def create_message(from_addr, from_addr_name, to_addr, cc_addr, subject, body):
            cset = 'utf-8'
            msg = MIMEMultipart()
            msg["Subject"] = subject
            msg["From"] = from_addr_name+"<"+from_addr+">"
            msg["To"] = to_addr
            msg["Cc"] = cc_addr
            msg["Date"] = formatdate()
            body = MIMEText(body.encode("utf-8"), 'plain', 'utf-8')
            msg.attach(body)
            return msg

        def send(from_addr, to_addrs, cc_addrs, msg):
            # set smtp server
            smtp = smtplib.SMTP(EMAIL_HOST)
            smtp.ehlo()
            smtp.starttls()
            smtp.ehlo

            # pdb.set_trace()
            # smtp.login(from_addr, "Y$0cTe@ms#2023")
            smtp.login(from_addr, EMAIL_HOST_PASSWORD)
            # smtp = smtplib.SMTP("smtp.jp.ykgw.net:25")
            sendToList = to_addrs.split(',')+cc_addrs.split(',')
            #  print (sendToList)
            smtp.sendmail(from_addr, sendToList, msg.as_string())
            smtp.close()
        # "ysoc.supportteam@yokogawa.com"  # "Y-SOC@yokogawa.com"
        from_addr = EMAIL_HOST_USER#"yil-ccc-autoalerts@yokogawa.com"#settings.EMAIL_HOST_USER  # "ysoc.supportteam@yokogawa.com"
        print("Senders EMAIL: ",from_addr)
        from_addr_name = "Y-SOC"
        to_addrs = "ITOTSOC-AutoAlerts@yokogawa.com,parachi.saikoushik@yokogawa.com,ajaysandip@yokogawa.com" 
        cc_addrs = str(myuser.EmailID)

        # subject = "Welcome to YSOC IntelliSense App !!"
        # body = "Hello " + myuser.FirstName + "!! \n" + \
        #     "Welcome to YSOC IntelliSense App!! \nThank you for visiting our website\n. We have also sent you a confirmation email. Please validate your email address before kick start. \n\nThanking You\nTeam YSOC IntelliSense App"
        subject = "YSOC IntelliSense App:New User Activation Request."
        body = "Hello Admin,\n" + \
            "A new user '" + myuser.FirstName +" " +myuser.LastName+"' has requested for account activation.\nPlease review this request and complete the user onboarding process.\n\nWarm Regards,\nTeam YSOC IntelliSense App."

        msg = create_message(from_addr, from_addr_name,
                             to_addrs, cc_addrs, subject, body)

        # pdb.set_trace()
        send(from_addr, to_addrs, cc_addrs, msg)

        print('email has been sent')

        # subject = "Welcome to YSOC IntelliSense App !!"
        # message = "Hello " + myuser.FirstName + "!! \n" + \
        #     "Welcome to YSOC IntelliSense App!! \nThank you for visiting our website\n. We have also sent you a confirmation email. Please validate your email address before kick start. \n\nThanking You\nTeam YSOC IntelliSense App"
        # from_email = settings.EMAIL_HOST_USER
        # to_list = [myuser.EmailID]
        # send_mail(subject, message, from_email, to_list, fail_silently=True)

        # # Email Address Confirmation Email
        # current_site = get_current_site(request)
        # email_subject = "Email Validation by Team YSOC IntelliSense App !!"
        # message2 = render_to_string('email_confirmation.html', {

        #     'name': myuser.FirstName,
        #     'domain': current_site.domain,
        #     'uid': urlsafe_base64_encode(force_bytes(myuser.pk)),
        #     'token': generate_token.make_token(myuser)
        # })
        # email = EmailMessage(
        #     email_subject,
        #     message2,
        #     settings.EMAIL_HOST_USER,
        #     [myuser.EmailID],
        # )
        # email.fail_silently = True
        # email.send()
    except Exception as e:
        logger.exception(
            "Error at send_email funtion in authentication.views as:%s", e)


@cache_control(no_cache=True, must_revalidate=True, no_store=True)
def signup(request):
    try:
        # pdb.set_trace()
        if request.method == "POST":
            account_password1 = str(
                "YKGW"+str(request.POST['Password1']).strip()+"YSOC")
            account_password1_sha256 = handler.hash(account_password1)

            app_user = {
                'UserAccountActivated': False,
                'UserName': str(request.POST['UserName']).capitalize().strip(),
                'FirstName': str(request.POST['FirstName']).strip(),
                'LastName': str(request.POST['LastName']).strip(),
                'EmailID': str(request.POST['EmailID']).strip(),
                'Password':  account_password1_sha256,
            }

            if "@yokogawa.com" not in str(request.POST['EmailID']).lower():
                messages.error(
                    request, "EmailID must be within Yokogawa domain! Please try again.")
                return redirect('signup')

            if app_user_info.objects.filter(EmailID=app_user['EmailID']).exists():
                messages.error(request, "EmailID Already Registered, please contact 'ITOTSOC-AutoAlerts@yokogawa.com' for queries!!")
                return redirect('signup')

            if app_user_info.objects.filter(UserName=app_user['UserName']):
                messages.error(
                    request, "Username already exist! Please try some other username.")
                return redirect('signup')

            if len(app_user['UserName']) > 50:
                messages.error(
                    request, "Username must be under 50 charcters!!")
                return redirect('signup')

            if len(str(request.POST['Password1']).strip()) < 8:
                messages.error(
                    request, "Password should be minimum of 8 charcters!!")
                return redirect('signup')

            if str(request.POST['Password1']).strip() != str(request.POST['Password2']).strip():
                messages.error(request, "Passwords miss matched!!")
                return redirect('signup')

            if not app_user['UserName'].isalnum():
                messages.error(request, "Username must be Alpha-Numeric!!")
                return redirect('signup')

            myuser = app_user_info.objects.create(UserName=app_user['UserName'],
                                                  FirstName=app_user['FirstName'], LastName=app_user[
                'LastName'], EmailID=app_user['EmailID'], Password=app_user['Password'],
                UserAccountActivated=app_user['UserAccountActivated'],)
            #   UserJoinedDate=dt.datetime.now())
            myuser.first_name = app_user['FirstName']
            myuser.last_name = app_user['LastName']
            myuser.is_active = False

            messages.success(
                request, "Your Account has been created succesfully and being reviewed by YSOC IntelliSense App Admin...")

            # messages.success(
            #     request, "Your Account has been created succesfully!! Please check your email to confirm your email address in order to activate your account.")
            send_email(myuser, request)

            return redirect('signin')

        return render(request, "authentication/signup.html")
    except Exception as e:
        logger.exception(
            "Error at signup funtion in authentication.views as:%s", e)


def activate(request, uidb64, token):
    try:
        # pdb.set_trace()
        try:
            uid = force_str(urlsafe_base64_decode(uidb64))
            myuser = app_user_info.objects.get(pk=uid)
        except (TypeError, ValueError, OverflowError, User.DoesNotExist):
            myuser = None

        if myuser is not None and generate_token.check_token(myuser, token):
            myuser.is_active = True
            myuser.profile.signup_confirmation = True
            myuser.save()
            login(request, myuser)
            messages.success(request, "Your Email is now Confirmed!!")
            return redirect('signin')
        else:
            return render(request, 'activation_failed.html')
    except Exception as e:
        logger.exception(
            "Error at activate funtion in authentication.views as:%s", e)


# @cache_control(no_cache=True, must_revalidate=True, no_store=True)
# @login_required(login_url="/index")
@ensure_csrf_cookie
def signin(request):
    try:
        # pdb.set_trace()
        #request.session.flush()
        data_com = get_user_session(request)
        if request.method == 'POST':
            UserName = str(request.POST['UserName']).capitalize().strip()
            account_password1 = str(request.POST['Password1']).strip()

            user = authenticate(username=UserName, password=account_password1)
            if user == None:
                try:
                    # pdb.set_trace()
                    try:
                        user = app_user_info.objects.get(UserName=UserName)
                    except Exception as e:
                        messages.error(request, "UserName Doesn't Matched!!")
                        return redirect('signin')

                    if user.UserAccountActivated == True:
                        account_password1_sha256 = user.Password
                        password_matched = handler.verify(str(
                            "YKGW"+account_password1.strip()+"YSOC"), account_password1_sha256)
                        if password_matched:
                            UserName = user.UserName
                            request.session['LoggedUser'] = UserName
                            request.session['LoggedUserEmainID'] = user.EmailID
                            if user.IsUserLoggedInToApp ==False:
                                app_user_info.objects.filter(UserName=UserName).update(IsUserLoggedInToApp=True)
                            
                            app_UserAccountActivated = True
                            app_UserPassword_Matched = True
                        else:
                            UserName =None
                            app_UserAccountActivated = True
                            app_UserPassword_Matched = False
                        
                    else:
                        UserName = None
                        app_UserAccountActivated = False
                except Exception as e:
                    logger.exception("User " + UserName +
                                     " doesn't found in DB")
                    messages.error(
                        request, "Hey, Username/Password Unavailable.")
                    return redirect('signin')
            else:
                login(request, user)
                UserName = user.username
                request.session['LoggedUser'] = UserName
                request.session['LoggedUserEmainID'] = user.email

            if UserName !=None and app_UserPassword_Matched: # is not None:
                data_com = get_user_session(request)
                data_com |= {"UserLoggedIn":  True}
                # UserLoggedIn = True
                # LoggedUser = request.session.get('LoggedUser')

                # print("\n @signin:", request.session['LoggedUser'],
                #       "\n ", request.session['LoggedUserEmainID'])
                # data_com = {"LoggedUser": LoggedUser,
                #             "UserLoggedIn": UserLoggedIn
                #             }
                # FirstName = user.first_name
                # data_com.user.FirstName
                # messages.success(request, "Logged In Sucessfully!!")
                return render(request, "ysoc_intellisense/user_home.html", data_com)
                # return render(request, "ysoc_intellisense/profile.html", data_com)
            elif not app_UserAccountActivated:
                messages.info(
                    request, "Hey, Your Account is still under review at App Admin. Please chase 'ITOTSOC-AutoAlerts@yokogawa.com' for further queries!!")
                return redirect('signin')
            elif not app_UserPassword_Matched:
                messages.error(request, "Password Doesn't Matched!!")
                return redirect('signin')
            else:
                messages.error(request, "Bad Credentials!!")
                return redirect('signin')

        return render(request, "authentication/signin.html")
    except Exception as e:
        logger.exception(
            "Error at signin funtion in authentication.views as:%s", e)


@cache_control(no_cache=True, must_revalidate=True, no_store=True)
@login_required(login_url="/signin")
def signout(request):
    try:
        data_com = get_user_session(request)
        pdb.set_trace()
        # logout(request)
        
        user = app_user_info.objects.get(UserName=data_com['LoggedUser'])
        if user.IsUserLoggedInToApp ==True:
            app_user_info.objects.filter(UserName=data_com['LoggedUser']).update(IsUserLoggedInToApp=False)
        # user.objects.update(UserLoggedInToApp=False)
        # UserLoggedIn = False
        # redirect('delete')
        # messages.success(request, "Logged Out Successfully!!")
        data_com = get_user_session(request)
        # print(data_com)
        # request.session.flush()
        delete_session(request)
        data_com = get_user_session(request)
        print(data_com)
        return render(request, 'authentication/home.html', data_com)#{"UserLoggedIn": False})
        # return redirect('home',{"UserLoggedIn":UserLoggedIn})
    except Exception as e:
        logger.exception(   
            "Error at signout funtion in authentication.views as:%s", e)


def delete_session(request):
    try:
        pdb.set_trace()
        data_com = get_user_session(request)
        del request.session[data_com['LoggedUser']]
        del request.session[data_com['LoggedUserEmainID']]
        request.session.cookies.clear()
        request.session.clear()#['LoggedUser'] ==None
        request.session.flush()
    except Exception as e:
        logger.exception(
            "Error at delete_session funtion in authentication.views as:%s", e)
    # return HttpResponse("<h1>dataflair<br>Session Data cleared</h1>")


def error_400_view(request, exception):
    # we add the path to the 400.html file
    # here. The name of our HTML file is 400.html
    return render(request, '400.html')


def error_403_view(request, exception):
    return render(request, '403.html')


def error_404_view(request, exception):
    return render(request, '404.html')


def error_500_view(request):
    return render(request, '500.html')
