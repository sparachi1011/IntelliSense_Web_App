# ### For Deployment in CCC server uncomment below below variable and update
# command = "C:\Users\ITOT_SOC_CCC\AppData\Local\Programs\Python\Python310\Scripts\gunicorn"
# pythonpath = "D:\YSOC_IntelliSense_Deployment\YSOC_IntelliSense\ysoc_intellisense_gui\ysoc_intellisense_gui"
# bind = "10.29.202.17:8000"

### For Local manhine Deployment uncomment below below variable and update
command = "C:\Users\464P0459\AppData\Local\Programs\Python\Python310\Scripts\gunicorn"
pythonpath = "C:\Users\464P0459\OneDrive - Yokogawa Electric Corporation\D-Drive\YIL\Python\YSOC_IntelliSense\ysoc_intellisense_gui\ysoc_intellisense_gui"
bind = "198.168.0.135:8000"


workers = 4
