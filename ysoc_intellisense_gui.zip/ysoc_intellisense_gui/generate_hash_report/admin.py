from django.contrib import admin

# Register your models here.
from generate_hash_report.models import generate_hash_report_db

admin.site.register(generate_hash_report_db)
