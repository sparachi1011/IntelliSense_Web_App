from django.apps import AppConfig


class GenerateHashReportConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'generate_hash_report'
