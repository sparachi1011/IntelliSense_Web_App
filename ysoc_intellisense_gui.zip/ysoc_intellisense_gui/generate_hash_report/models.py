from django.db import models


# Create your models here.


class generate_hash_report_db(models.Model):

    UserName = models.CharField(
        ("UserName"), max_length=100, null=False, unique=False, db_index=True)
    HASH_Output = models.CharField(
        ("HASH_Output"), max_length=100, primary_key=False, db_index=True)
    HASH_Searched_date = models.DateTimeField(auto_now_add=True)
    YSOC_IntelliSense_Verdict = models.CharField(
        ("YSOC_IntelliSense_Verdict"), max_length=50, blank=True, null=True)
    Virus_Total_No_of_Databases_Checked = models.FloatField(
        ("Virus_Total_No_of_Databases_Checked"), blank=True, null=True)
    Virus_Total_No_of_Reportings = models.FloatField(
        ("Virus_Total_No_of_Reportings"), blank=True, null=True)
    Virus_Total_Average_Score = models.FloatField(
        ("Virus_Total_Average_Score"), blank=True, null=True)
    Virus_Total_Report_Link = models.CharField(
        ("Virus_Total_Report_Link"), max_length=500, blank=True, null=True)
    Virus_Total_Remarks = models.CharField(
        ("Virus_Total_Remarks"), max_length=100, blank=True, null=True)
    OTX_Verdicts = models.CharField(
        ("OTX_Verdicts"), max_length=50, blank=True, null=True)
    OTX_Pulse_Count = models.FloatField(
        ("OTX_Pulse_Count"), blank=True, null=True)
    OTX_Remarks = models.CharField(
        ("OTX_Remarks"), max_length=50, blank=True, null=True)    
    # # Abuse_Confidence_Score = models.FloatField(
    # #     ("Abuse_Confidence_Score"), blank=True, null=True)
    # # Abuse_Total_Reports = models.FloatField(
    # #     ("Abuse_Total_Reports"), blank=True, null=True)
    # # Abuse_Last_Reported_At = models.DateTimeField(
    # #     ("Abuse_Last_Reported_At"), max_length=50, blank=True, null=True)
    # # Abuse_Remarks = models.CharField(
    # #     ("Abuse_Remarks"), max_length=100, blank=True, null=True)
    # # Virus_Total_No_of_Databases_Checked = models.FloatField(
    # #     ("Virus_Total_No_of_Databases_Checked"), blank=True, null=True)
    # # Virus_Total_No_of_Reportings = models.FloatField(
    # #     ("Virus_Total_No_of_Reportings"), blank=True, null=True)
    # # Virus_Total_Average_Score = models.FloatField(
    # #     ("Virus_Total_Average_Score"), blank=True, null=True)
    # # Virus_Total_Report_Link = models.CharField(
    # #     ("Virus_Total_Report_Link"), max_length=500, blank=True, null=True)
    # Virus_Total_Hash_Id = models.CharField(
    #     ("Virus_Total_Hash_Id"), max_length=100, blank=True, null=True) #"24a42a912c6ad98ab3910cb1e031edbdf9ed6f452371d5696006c9cf24319147"
    # # Virus_Total_Hash_Link = models.URLField(
    # #     ("Virus_Total_Hash_Link"), max_length=500, blank=True, null=True) #"https://www.virustotal.com/api/v3/files/24a42a912c6ad98ab3910cb1e031edbdf9ed6f452371d5696006c9cf24319147"
    # # Virus_Total_Sigma_Analysis_Stats = models.CharField(
    # #     ("Virus_Total_Sigma_Analysis_Stats"), max_length=50, blank=True, null=True) #{"critical": 1,"high": 3,"medium": 11,"low": 1}
    # # Virus_Total_Crowdsourced_Description = models.CharField(
    # #     ("Virus_Total_Crowdsourced_Description"), max_length=512, blank=True, null=True) #"This signature fires on the presence of Base64 encoded URI prefixes (http:// and https://) across any file. The simple presence of such strings is not inherently an indicator of malicious content, but is worth further investigation."
    # Virus_Total_md5 = models.CharField(
    #     ("Virus_Total_md5"), max_length=100, blank=True, null=True)
    # Virus_Total_Sha256 = models.CharField(
    #     ("Virus_Total_Sha256"), max_length=100, blank=True, null=True) #"24a42a912c6ad98ab3910cb1e031edbdf9ed6f452371d5696006c9cf24319147"
    # Virus_Total_Sha1 = models.CharField(
    #     ("Virus_Total_Sha1"), max_length=100, blank=True, null=True)
    # # Virus_Total_Crowdsourced_Ids_Stats = models.CharField(
    # #     ("Virus_Total_Crowdsourced_Ids_Stats"), max_length=50, blank=True, null=True) #{"high": 0,"medium": 1,"low": 4,"info": 1}
    # # Virus_Total_Total_Votes = models.CharField(
    # #     ("Virus_Total_Total_Votes"), max_length=50, blank=True, null=True) #{"harmless": 0,"malicious": 1}
    # # Virus_Total_Type_Tag = models.CharField(
    # #     ("Virus_Total_Type_Tag"), max_length=10, blank=True, null=True) # "text"
    # # Virus_Total_Last_Submission_Date = models.IntegerField(
    # #     ("Virus_Total_Last_Submission_Date"), blank=True, null=True) #1720024434
    # # Virus_Total_Sigma_Analysis_Summary = models.JSONField(
    # #     ("Virus_Total_Sigma_Analysis_Summary"), blank=True, null=True) # {"Joe Security Rule Set (GitHub)": {"critical": 1,"high": 0,"medium": 0,"low": 0},"Sigma Integrated Rule Set (GitHub)": {"critical": 0,"high": 3,"medium": 11,"low": 1}}
    # # Virus_Total_Sandbox_Verdicts = models.JSONField(
    # #     ("Virus_Total_Sandbox_Verdicts"), blank=True, null=True) # {"Zenbox": {"category": "malicious","malware_classification": ["MALWARE","EVADER"],"sandbox_name": "Zenbox","confidence": 84},"Dr.Web vxCube": {"category": "malicious","malware_classification": ["MALWARE"],"sandbox_name": "Dr.Web vxCube"}}
    # # Virus_Total_Reputation = models.FloatField(
    # #     ("Virus_Total_Reputation"), blank=True, null=True) # -9
    # # Virus_Total_Sigma_Analysis_Description = models.CharField(
    # #     ("Virus_Total_Sigma_Analysis_Description"), max_length=255, blank=True, null=True) # "Windows PowerShell"
    # # Virus_Total_Sigma_Analysis_Original_Filename = models.CharField(
    # #     ("Virus_Total_Sigma_Analysis_Original_Filename"), max_length=255, blank=True, null=True) # "PowerShell.EXE"
    # # Virus_Total_Sigma_Analysis_Hashes = models.CharField(
    # #     ("Virus_Total_Sigma_Analysis_Hashes"), max_length=200, blank=True, null=True) # "SHA1=1B3B40FBC889FD4C645CC12C85D0805AC36BA254,MD5=95000560239032BC68B4C2FDFCDEF913,SHA256=D3F8FADE829D2B7BD596C4504A6DAE5C034E789B6A3DEFBE013BDA7D14466677,IMPHASH=741776AACCFC5B71FF59832DCDCACE0F"
    # # Virus_Total_Sigma_Analysis_Signature_Status = models.TextField(
    # #     ("Virus_Total_Sigma_Analysis_Signature_Status"), max_length=20, blank=True, null=True) # Unavailable
    # Virus_Total_Average_Score = models.IntegerField(
    #     ("Virus_Total_Average_Score"), blank=True, null=True) # {"malicious": 23,"suspicious": 0,"undetected": 41,"harmless": 0,"timeout": 0,"confirmed-timeout": 0,"failure": 0,"type-unsupported": 14}
    # Virus_Total_Remarks = models.CharField(
    #     ("Virus_Total_Remarks"), max_length=50, blank=True, null=True)    # None
    # OTX_Verdicts = models.CharField(
    #     ("OTX_Verdicts"), max_length=50, blank=True, null=True)
    # OTX_Pulse_Count = models.IntegerField(
    #     ("OTX_Pulse_Count"), blank=True, null=True)
    # OTX_Pulse_Name = models.CharField(
    #     ("OTX_Pulse_Name"), max_length=100, blank=True, null=True) # 'North Korean based backdoor packs a punch'
    # OTX_Description = models.CharField(
    #     ("OTX_Description"), max_length=255, blank=True, null=True) # : 'This report analyzes a new threat campaign discovered in late May, featuring multiple layers and ultimately delivering a previously undocumented backdoor. The campaign specifically targets Aerospace and Defense companies, sectors of particular interest to North Korean threat groups. The backdoors analyzed are simple yet powerful tools with various obfuscation techniques and capabilities like reconnaissance, data collection, and remote control. While attribution is made with low confidence to the Kimsuky threat group, there are indications of multiple developers potentially involved, including the possible outsourcing of some malware creation capabilities.',
    # OTX_Tags = models.CharField(
    #     ("OTX_Tags"), max_length=255, blank=True, null=True) # ['defense', 'nikigo', 'espionage', 'aerospace', 'nikihttp', 'northkorea', 'backdoor']
    # OTX_Remarks = models.CharField(
    #     ("OTX_Remarks"), max_length=50, blank=True, null=True) # None
