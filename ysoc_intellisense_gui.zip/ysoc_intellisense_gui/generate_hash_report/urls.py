from django.urls import path

from generate_hash_report import views

urlpatterns = [
    path('get_hash_report', views.process_generate_hash_report_request,
         name='get_hash_report'),
    path('get_hash_bulk_report', views.process_generate_hash_report_request_bulk,
         name='get_hash_bulk_report'),
    path('export_hashs/', views.export_hash_to_excel, name='export_hash_to_excel'), 

]

handler400 = 'generate_hash_report.views.error_400_view'
handler403 = 'generate_hash_report.views.error_403_view'
handler404 = 'generate_hash_report.views.error_404_view'
handler500 = 'generate_hash_report.views.error_500_view'
