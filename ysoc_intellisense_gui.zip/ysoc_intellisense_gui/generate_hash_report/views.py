from ysoc_intellisense_imports import os, pd, pdb, csv, dt, logger, random, HttpResponse, render, redirect, read_frame, Workbook, cache_control
from ysoc_intellisense_globals import *

# from authentication.models import app_user_info
from generate_hash_report.models import generate_hash_report_db
from integrated_database_search.ysoc_intellisense_wrapper import main


def get_user_session(request):
    try:
        # print(request)
        # pdb.set_trace()
        data_com = {"LoggedUser": request.session.get('LoggedUser'),
                    "LoggedUserEmainID": request.session.get('LoggedUserEmainID'),
                    "UserLoggedIn": True,
                    'DraftRequestStatus': 'inprogress',
                    }
        # # if str(request.session.get('LoggedUser')).capitalize().strip() !='None':
        # #     data_com |={"LoggedUser" :str(request.session.get('LoggedUser')).capitalize().strip(),
        # #                 "LoggedUserEmainID": request.session.get('LoggedUserEmainID'),}
        # # elif str(request.POST['UserName']).capitalize().strip() !='None':
        # #     data_com |={"LoggedUser" :str(request.POST['UserName']).capitalize().strip(),
        # #                 # "LoggedUserEmainID": request.session.get('LoggedUserEmainID'),
        # #                 }
        # # elif str(request.GET['UserName']).capitalize().strip() !='None':
        # #     data_com |={"LoggedUser" :str(request.GET['UserName']).capitalize().strip(),
        # #                 # "LoggedUserEmainID": request.session.get('LoggedUserEmainID'),
        # #                 }

        # # pdb.set_trace()
        # if request.session.get('LoggedUser') !=None:
        #     ysoc_intellisense_user_info_qs = app_user_info.objects.all().filter(
        #             UserName=data_com['LoggedUser'])
        #     ysoc_intellisense_user_info_df = read_frame(
        #         ysoc_intellisense_user_info_qs)
        #     # print(ysoc_intellisense_user_info_df)
        #     IsUserLoggedInToApp = ysoc_intellisense_user_info_df['IsUserLoggedInToApp']
        #     data_com |={"UserLoggedIn" :IsUserLoggedInToApp[0],
        #                 "ysoc_intellisense_user_info_df" :ysoc_intellisense_user_info_df }
        # # print("data_com\n",data_com)
        return data_com
    except Exception as e:
        logger.exception(
            "Error at get_user_session funtion in generate_hash_report.views as:%s", e)

# @cache_control(no_cache=True, must_revalidate=True, no_store=True)


def render_results_to_html(data_com, ysoc_intelli_sense_inputs):
    try:

        ysoc_intelli_sense_results = main(ysoc_intelli_sense_inputs, 'HASH_Output')
        ysoc_intelli_sense_results["UserName"] = data_com['LoggedUser']
        # pdb.set_trace()
        # for col in columns_for_ysoc_instellisense_report:
        #     if col in ysoc_intelli_sense_results.columns:
        #         pass
        #     else:
        #         ysoc_intelli_sense_results[col] = 99999
        # pdb.set_trace()

        # ysoc_intelli_sense_results = ysoc_intelli_sense_results.fillna(0.00)
        print(ysoc_intelli_sense_results)

        ysoc_intelli_sense_results = ysoc_intellisense_verdict(
            ysoc_intelli_sense_results)

        ysoc_intelli_sense_results_to_ui = pd.DataFrame(
            ysoc_intelli_sense_results,
            columns=columns_to_render_in_html["columns_to_render_for_Hash"])
        ysoc_intelli_sense_results_html = ysoc_intelli_sense_results_to_ui.to_html(
            index=False, border=5, render_links=True)
        data_com['table_html'] = ysoc_intelli_sense_results_html

        return data_com, ysoc_intelli_sense_results
    except Exception as e:
        logger.exception(
            "Error at render_results_to_html funtion in generate_hash_reports.views as:%s", e)


def process_generate_hash_report_request(request):
    try:

        data_com = get_user_session(request)
        # pdb.set_trace()
        # if data_com["UserLoggedIn"] and data_com["LoggedUser"] !=None:
        if request.method == "GET":
            return render(request, "generate_hash_report/generate_hash_report.html",
                        data_com)
        elif request.method == "POST":

            if "HASH_Value" in request.POST:
                requested_hash_values = str(request.POST['HASH_Value']).strip()
                requested_hash_values = requested_hash_values.split(";")
                ysoc_intelli_sense_inputs = pd.DataFrame(
                    requested_hash_values, columns=["HASH_Output"])

                if not ysoc_intelli_sense_inputs.empty:
                    data_com, ysoc_intelli_sense_results = render_results_to_html(
                        data_com, ysoc_intelli_sense_inputs)

                return render(request, "generate_hash_report/generate_individual_report.html",
                            data_com)
        # else:
        #     return redirect('signin')
            
    except Exception as e:
        logger.exception(
            "Error at process_generate_hash_report_request funtion in generate_hash_reports.views as:%s", e)


def update_generate_hash_report_db(data_com, ysoc_intelli_sense_results):
    try:

        # ysoc_intelli_sense_results = ysoc_intelli_sense_results.fillna(np.nan).replace([
        #     np.nan], [None])
        # ysoc_intelli_sense_results = ysoc_intelli_sense_results.astype("string")
        # pdb.set_trace()
        update_generate_hash_report_db = generate_hash_report_db.objects.bulk_create(
            [generate_hash_report_db(
                UserName=data_com["LoggedUser"],
                HASH_Output=row["HASH_Output"],
                YSOC_IntelliSense_Verdict=row["YSOC_IntelliSense_Verdict"],
                Virus_Total_No_of_Databases_Checked=row["Virus_Total_No_of_Databases_Checked"],
                Virus_Total_No_of_Reportings=row["Virus_Total_No_of_Reportings"],
                Virus_Total_Average_Score=row["Virus_Total_Average_Score"],
                Virus_Total_Report_Link=row["Virus_Total_Report_Link"],
                Virus_Total_Remarks=row["Virus_Total_Remarks"],
                OTX_Verdicts=row["OTX_Verdicts"],
                OTX_Pulse_Count=row["OTX_Pulse_Count"],
                OTX_Remarks=row["OTX_Remarks"],)
                # Virus_Total_Hash_Id=row["Virus_Total_Hash_Id"],
                # Virus_Total_md5=row["Virus_Total_md5"],
                # Virus_Total_Sha256=row["Virus_Total_Sha256"],
                # Virus_Total_Sha1=row["Virus_Total_Sha1"],
                # Virus_Total_Average_Score=row["Virus_Total_Average_Score"],
                # Virus_Total_Remarks=row["Virus_Total_Remarks"],
                # OTX_Verdicts = row["OTX_Verdicts"],
                # OTX_Pulse_Count = row["OTX_Pulse_Count"],
                # OTX_Pulse_Name=row["OTX_Pulse_Name"],
                # OTX_Description=row["OTX_Description"],
                # OTX_Tags=row["OTX_Tags"],
                # OTX_Remarks=row["OTX_Remarks"],)

                for _, row in ysoc_intelli_sense_results.iterrows()])
    except Exception as e:
        logger.exception(
            "Error at update_generate_hash_report_db funtion in generate_hash_reports.views as:%s", e)


def ysoc_intellisense_verdict(ysoc_intelli_sense_results):
    try:

        for indx in ysoc_intelli_sense_results.index.to_list():
            # abuse_ipdb_score = ysoc_intelli_sense_results.loc[indx,
            #                                                   "Abuse_Confidence_Score"]
            vt_score = ysoc_intelli_sense_results.loc[indx,
                                                      "Virus_Total_Average_Score"]
            otx_verdict = ysoc_intelli_sense_results.loc[indx, "OTX_Verdicts"]

            if vt_score > 2 or otx_verdict == "Malicious":
                ysoc_intelli_sense_results.loc[indx,
                                               'YSOC_IntelliSense_Verdict'] = "Malicious"
            # elif (vt_score >= 3 or otx_verdict == "Malicious") \
            #                     and sum([vt_score >= 2, otx_verdict == "Malicious"]) == 1:
            #                 ysoc_intelli_sense_results.loc[indx,
            #                                             'YSOC_IntelliSense_Verdict'] = "Suspicious"                

            # if vt_score >= 2 and abuse_ipdb_score >= 30:
            #     ysoc_intelli_sense_results.loc[indx,
            #                                    'YSOC_IntelliSense_Verdict'] = "Malicious"
            # elif (vt_score >= 2 or abuse_ipdb_score >= 30) and otx_verdict == "Malicious":
            #     ysoc_intelli_sense_results.loc[indx,
            #                                    'YSOC_IntelliSense_Verdict'] = "Malicious"
            # elif (vt_score >= 2 or abuse_ipdb_score >= 30 or otx_verdict == "Malicious") \
            #         and sum([vt_score >= 2, abuse_ipdb_score >= 30, otx_verdict == "Malicious"]) == 1:
            #     ysoc_intelli_sense_results.loc[indx,
            #                                    'YSOC_IntelliSense_Verdict'] = "Suspicious"
            else:
                ysoc_intelli_sense_results.loc[indx,
                                               'YSOC_IntelliSense_Verdict'] = "Unknown"

        return ysoc_intelli_sense_results
    except Exception as e:
        logger.exception(
            "Error at ysoc_intellisense_verdict funtion in generate_hash_reports.views as:%s", e)


def process_generate_hash_report_request_bulk(request):
    try:
        data_com = get_user_session(request)
        # pdb.set_trace()
        # print("****")
        # if data_com["UserLoggedIn"] and data_com["LoggedUser"] !=None: 
        if request.method == 'POST':
            # handle_uploaded_file(request.FILES['file'], str(request.FILES['file']))
            file_name = request.FILES['Uploaded_File']
            if ".csv" in str(file_name):
                file_data = pd.read_csv(file_name)

            elif ".xlsx" in str(file_name):
                file_data = pd.read_excel(file_name)
            
            if not file_data.empty:
                file_data=file_data.applymap(lambda x: x.strip() if type(x)==str else x)
                file_hash_output_col = file_data.columns[0]
                file_data = file_data.rename(columns={
                    file_hash_output_col: "HASH_Output"})
                ysoc_intelli_sense_inputs = file_data.copy()
                data_com, ysoc_intelli_sense_results = render_results_to_html(
                    data_com, ysoc_intelli_sense_inputs)

                if not ysoc_intelli_sense_results.empty:
                    # pass
                    update_generate_hash_report_db(
                        data_com, ysoc_intelli_sense_results)

            return render(request, "generate_hash_report/generate_hash_bulk_report.html",
                        data_com)
        # else:
        #     return redirect('signin')
    except Exception as e:
        logger.exception(
            "Error at process_generate_hash_report_request_bulk funtion in generate_hash_reports.views as:%s", e)


def remove_tz_from_dataframe(df_in):
    try:
        df = df_in.copy()
        col_times = [col for col in df.columns if any(
            [isinstance(x, pd.Timestamp) for x in df[col]])]
        for col in col_times:
            df[col] = pd.to_datetime(
                df[col], infer_datetime_format=True)
            df[col] = df[col].dt.tz_localize(None)
        return df
    except Exception as e:
        logger.exception(
            "Error at remove_tz_from_dataframe funtion in generate_hash_reports.views as:%s", e)


def export_hash_to_excel(request):
    try:
        data_com = get_user_session(request)
        # if data_com["UserLoggedIn"] and data_com["LoggedUser"] !=None:
        export_file_name = "YSOC_IntelliSense_Report_" + \
            str(dt.datetime.now().strftime("%Y_%m_%d_%H_%M_%S"))+".xlsx"
        response = HttpResponse(content_type='application/ms-excel')
        response['Content-Disposition'] = 'attachment; filename=' + \
            export_file_name

        wb = Workbook()
        ws = wb.active
        ws.title = "YSOC_IntelliSense_Report"

        # Add data from the model
        YSOC_IntelliSense_Report_qs = generate_hash_report_db.objects.all().filter(
            UserName=data_com['LoggedUser'])
        YSOC_IntelliSense_Report_df = read_frame(
            YSOC_IntelliSense_Report_qs)
        if not YSOC_IntelliSense_Report_df.empty:
            YSOC_IntelliSense_Report_df = YSOC_IntelliSense_Report_df.drop(
                ["id"], axis=1)
            YSOC_IntelliSense_Report_df = YSOC_IntelliSense_Report_df.drop_duplicates(
                subset=["UserName", "HASH_Output"])
            YSOC_IntelliSense_Report_df = remove_tz_from_dataframe(
                YSOC_IntelliSense_Report_df)

            # Add headers

            # headers = YSOC_IntelliSense_Report_df.columns
            columns_for_ysoc_instellisense_report = ["UserName", "HASH_Output"]
            for db_col_list in ysoc_intellisense_threatintel_dbs["ysoc_intellisense_threatintel_dbs_for_hash_url"].values():
                columns_for_ysoc_instellisense_report.extend(db_col_list)

            ws.append(columns_for_ysoc_instellisense_report)
            YSOC_IntelliSense_Report_df = pd.DataFrame(
                YSOC_IntelliSense_Report_df, columns=columns_for_ysoc_instellisense_report)
            for indx in YSOC_IntelliSense_Report_df.index.to_list():
                ws.append(
                    YSOC_IntelliSense_Report_df.loc[indx, :].values.tolist())

        # Save the workbook to the HttpResponse
            wb.save(response)
            # pdb.set_trace()
            # data_com["Exported_Data"] = response
            return response
            # return render(request, "generate_hash_report/generate_hash_report.html",
            #               data_com)
        else:
            pass
        # else:
        #     return redirect('signin')
    except Exception as e:
        logger.exception(
            "Error at export_hash_to_excel funtion in generate_hash_reports.views as:%s", e)


def error_400_view(request, exception):
    # we add the path to the 400.html file
    # here. The name of our HTML file is 400.html
    return render(request, '400.html')


def error_403_view(request, exception):
    return render(request, '403.html')


def error_404_view(request, exception):
    return render(request, '404.html')


def error_500_view(request):
    return render(request, '500.html')
