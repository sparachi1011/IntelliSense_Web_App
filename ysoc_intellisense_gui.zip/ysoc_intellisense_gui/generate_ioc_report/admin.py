from django.contrib import admin

# Register your models here.
from generate_ioc_report.models import generate_ioc_report_db

admin.site.register(generate_ioc_report_db)
