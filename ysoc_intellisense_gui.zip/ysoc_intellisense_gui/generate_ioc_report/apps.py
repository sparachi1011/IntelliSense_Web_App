from django.apps import AppConfig


class GenerateIOCReportConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'generate_ioc_report'
