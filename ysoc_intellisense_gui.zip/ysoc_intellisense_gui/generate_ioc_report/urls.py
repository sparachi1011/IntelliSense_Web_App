from django.urls import path

from generate_ioc_report import views

urlpatterns = [
    path('get_ioc_report', views.process_generate_ioc_report_request,
         name='get_ioc_report'),
    path('get_ioc_bulk_report', views.process_generate_ioc_report_request_bulk,
         name='get_ioc_bulk_report'),
    path('export_iocs/', views.export_ioc_to_excel, name='export_ioc_to_excel'), 

]

handler400 = 'generate_ioc_report.views.error_400_view'
handler403 = 'generate_ioc_report.views.error_403_view'
handler404 = 'generate_ioc_report.views.error_404_view'
handler500 = 'generate_ioc_report.views.error_500_view'
