from django.contrib import admin

# Register your models here.
from generate_url_report.models import generate_url_report_db

admin.site.register(generate_url_report_db)
