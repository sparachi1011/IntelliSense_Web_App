from django.db import models


# Create your models here.


class generate_url_report_db(models.Model):
    UserName = models.CharField(
        ("UserName"), max_length=100, null=False, unique=False, db_index=True)
    URL_Output = models.CharField(
        ("URL_Output"), max_length=500, primary_key=False, db_index=True)
    URL_Searched_date = models.DateTimeField(auto_now_add=True)
    YSOC_IntelliSense_Verdict = models.CharField(
        ("YSOC_IntelliSense_Verdict"), max_length=50, blank=True, null=True)
    Virus_Total_No_of_Databases_Checked = models.FloatField(
        ("Virus_Total_No_of_Databases_Checked"), blank=True, null=True)
    Virus_Total_No_of_Reportings = models.FloatField(
        ("Virus_Total_No_of_Reportings"), blank=True, null=True)
    Virus_Total_Average_Score = models.FloatField(
        ("Virus_Total_Average_Score"), blank=True, null=True)
    Virus_Total_Report_Link = models.CharField(
        ("Virus_Total_Report_Link"), max_length=500, blank=True, null=True)
    Virus_Total_Remarks = models.CharField(
        ("Virus_Total_Remarks"), max_length=100, blank=True, null=True)
    OTX_Verdicts = models.CharField(
        ("OTX_Verdicts"), max_length=50, blank=True, null=True)
    OTX_Pulse_Count = models.FloatField(
        ("OTX_Pulse_Count"), blank=True, null=True)
    OTX_Remarks = models.CharField(
        ("OTX_Remarks"), max_length=50, blank=True, null=True)
    # # Abuse_Confidence_Score = models.FloatField(
    # #     ("Abuse_Confidence_Score"), blank=True, null=True)
    # # Abuse_Total_Reports = models.FloatField(
    # #     ("Abuse_Total_Reports"), blank=True, null=True)
    # # Abuse_Last_Reported_At = models.DateTimeField(
    # #     ("Abuse_Last_Reported_At"), max_length=50, blank=True, null=True)
    # # Abuse_Remarks = models.CharField(
    #     # ("Abuse_Remarks"), max_length=100, blank=True, null=True)
    # Virus_Total_Domain_ID = models.FloatField(
    #     ("Virus_Total_Domain_ID"), blank=True, null=True)
    # Virus_Total_Domain_Type = models.CharField(
    #     ("Virus_Total_Domain_Type"), max_length=50, blank=True, null=True)
    # Virus_Total_Categories = models.CharField(
    #     ("Virus_Total_Categories"), max_length=500, blank=True, null=True)
    # Virus_Total_Average_Score = models.IntegerField(
    #     ("Virus_Total_Average_Score"), blank=True, null=True)        
    # Virus_Total_Last_Analysis_Results = models.JSONField(
    #     ("Virus_Total_Last_Analysis_Results"), blank=True, null=True)          
    # Virus_Total_Remarks = models.CharField(
    #     ("Virus_Total_Remarks"), max_length=50, blank=True, null=True)
    # OTX_Verdicts = models.CharField(
    #     ("OTX_Verdicts"), max_length=50, blank=True, null=True)
    # OTX_Pulse_Count = models.IntegerField(
    #     ("OTX_Pulse_Count"), blank=True, null=True)
    # OTX_Remarks = models.CharField(
    #     ("OTX_Remarks"), max_length=50, blank=True, null=True)
    