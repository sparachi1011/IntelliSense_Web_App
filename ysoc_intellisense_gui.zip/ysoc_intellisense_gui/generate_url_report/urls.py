from django.urls import path

from generate_url_report import views

urlpatterns = [
    path('get_url_report', views.process_generate_url_report_request,
         name='get_url_report'),
    path('get_url_bulk_report', views.process_generate_url_report_request_bulk,
         name='get_url_bulk_report'),
    path('export_urls/', views.export_url_to_excel, name='export_url_to_excel'),

]

handler400 = 'generate_url_report.views.error_400_view'
handler403 = 'generate_url_report.views.error_403_view'
handler404 = 'generate_url_report.views.error_404_view'
handler500 = 'generate_url_report.views.error_500_view'
