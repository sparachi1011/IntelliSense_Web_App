
from ysoc_intellisense_imports import configvars, pd,np,dt,pdb, requests, logger


def get_report_from_abuse_ipdb(ab_api_keys_string, get_ip_scores, report_input):
    try:
        abuse_api_response_df = pd.DataFrame()

        def iterate_by_api_key(api_key):
            try:
                # pdb.set_trace()
                api_response_df = pd.DataFrame()
                AB_URL = 'https://api.abuseipdb.com/api/v2/check'
                days = '90'

                querystring = {
                    'ipAddress': get_ip_scores,
                    'maxAgeInDays': days
                }

                headers = {
                    'Accept': 'application/json',
                    'Key': str(api_key)
                }
                response = requests.request(
                    method='GET', url=AB_URL, headers=headers, params=querystring, verify=False)
                if response.status_code == 200:
                    req = response.json()
                    if report_input == 'IP_Address':
                        api_response_df[report_input] = [req['data']['ipAddress']]
                    api_response_df['Abuse_Confidence_Score'] = [
                        req['data']['abuseConfidenceScore']]
                    api_response_df['Abuse_Total_Reports'] = [
                        req['data']['totalReports']]
                    api_response_df['Abuse_Last_Reported_At'] = [
                        req['data']['lastReportedAt']]
                    api_response_df['Abuse_Remarks'] = ["None."]

                return api_response_df

            except Exception as e:
                logger.error(
                    'Error at iterate_by_api_key function while connecting to Abuse IPBD : %s', e)

        ab_api_keys_list = ab_api_keys_string.split(":,:")

        # abuse_api_response_df = iterate_by_api_key(ab_api_keys_list[0])
        # pdb.set_trace()
        abuse_api_response_df = pd.DataFrame()
        while len(abuse_api_response_df.index) == 0 :
            # ab_api_keys = iter(ab_api_keys_list)
            # ab_api_key = next(ab_api_keys)
            # if ab_api_key == ab_api_keys_list[-1:][0]:
            ab_api_key = np.random.choice(np.array(ab_api_keys_list))
            if ab_api_key:                
                print("AB API Key used for IP: ",get_ip_scores,"to get threat intel score is\n",ab_api_key)
                # pdb.set_trace()
                abuse_api_response_df = iterate_by_api_key(
                    ab_api_key)
                # pdb.set_trace()
                
                # abuse_api_response_df = iterate_by_api_key(
                #     ab_api_keys_list[-1:][0])
                # pdb.set_trace()
                if abuse_api_response_df["Abuse_Remarks"][0] != "None.":
                    abuse_api_response_df[report_input] = [
                        get_ip_scores]
                    abuse_api_response_df['Abuse_Remarks'] = [
                        "Unable to fetch Score's with available API Key's."]
                    abuse_api_response_df["Abuse_Last_Reported_At"]=[dt.datetime.now()]
                else:
                    if any(word in [np.nan,np.NaN,None,""] for word in [abuse_api_response_df["Abuse_Last_Reported_At"][0]]):
                        abuse_api_response_df["Abuse_Last_Reported_At"]=dt.datetime.now()#.strftime("%Y-%m-%dT%H-")
                # print(abuse_api_response_df)
            else:
                pass
                # abuse_api_response_df = iterate_by_api_key(ab_api_key)
        return abuse_api_response_df
    except Exception as e:
        logger.error(
            "Got error in get_report_from_abuse_ipdb function with error:%s.", e)


def abuse_ipdb_wrapper(get_all_ip_scores, report_input):
    try:
        # print("\n Abuse IPDB Report Start:")
        # pdb.set_trace()
        abuse_api_results = pd.DataFrame()
        api_results_df = get_all_ip_scores
        ab_api_keys_string = configvars.data['AB_API_KEY']  # .split(":,:")
        get_report_list = get_all_ip_scores[report_input].to_list()
        for report_value in get_report_list:
            abuse_api_results = abuse_api_results.append(
                get_report_from_abuse_ipdb(ab_api_keys_string, report_value, report_input), ignore_index=True)
        if not abuse_api_results.empty:
            # find elements in api_results_df that are not in abuse_api_results
            unfetched_reports = api_results_df[~(api_results_df[report_input].isin(
                abuse_api_results[report_input]))].reset_index(drop=True)

            for row in unfetched_reports.itertuples(index=True, name='Pandas'):
                missed_report = pd.DataFrame()
                missed_report[report_input] = [row[1]]
                missed_report['Abuse_Remarks'] = [
                    "Unable to fetch Score's from Abuse IPDB by YSOC Intellisense Tool."]
                abuse_api_results = abuse_api_results.append(
                    missed_report, ignore_index=True)

            # print(abuse_api_results)
        # print("\n Abuse IPDB Report End:")

        return abuse_api_results
    except Exception as e:
        logger.error(
            "Got error in abuse_ipdb_wrapper function with error:%s.", e)
