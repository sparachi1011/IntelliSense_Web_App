
from ysoc_intellisense_imports import configvars, pd, requests, logger, time, dt


def get_ioc_from_bad_ip_db(bad_ip_api_keys_string, get_ip_scores):
    try:
        bad_ip_api_response_df = pd.DataFrame()

        def iterate_by_api_key(api_key):
            try:
                api_response_df = pd.DataFrame()
                url = 'https://www.badips.com/get/info/' + get_ip_scores
                response = requests.get(url)
                if response.status_code == 200:
                    result = response.json()
                    api_response_df['IP_Address'] = [get_ip_scores]
                    for each in result['LastReport']:
                        timeReport = dt.fromtimestamp(
                            result['LastReport'].get(each))
                    api_response_df['Bad_IP_No_of_Reportings'] = [
                        result['ReporterCount']['sum']]
                    api_response_df['Bad_IP_Last_Reported'] = [timeReport]
                    api_response_df['Bad_IP_Remarks'] = ["None."]

                return api_response_df
            except Exception as e:
                api_response_df['Bad_IP_Remarks'] = [e]
                logger.exception(
                    "Error unpacking response from Bad IP :%s",e)

            # except Exception as e:
            #     logger.error(
            #         'Error at iterate_by_api_key function while connecting to Bad IP database : ' + e)

        vt_api_keys_list = bad_ip_api_keys_string.split(":,:")

        bad_ip_api_response_df = iterate_by_api_key(vt_api_keys_list[0])

        while bad_ip_api_response_df.empty:
            vt_api_keys = iter(vt_api_keys_list)
            vt_api_key = next(vt_api_keys)
            if vt_api_key == vt_api_keys_list[-1:][0]:
                bad_ip_api_response_df = iterate_by_api_key(
                    vt_api_keys_list[-1:][0])
                if bad_ip_api_response_df.empty:
                    bad_ip_api_response_df['IP_Address'] = [
                        get_ip_scores]
                    bad_ip_api_response_df['Bad_IP_Remarks'] = [
                        "Unable to fetch IOC Score's with available API Key's."]
            else:
                bad_ip_api_response_df = iterate_by_api_key(vt_api_key)
        return bad_ip_api_response_df
    except Exception as e:
        logger.error(
            "Got error in get_ioc_from_bad_ip_db function with error:%s.", e)


def bad_ip_db_wrapper(get_all_ip_scores):
    try:
        print("\n Bad IP Report Start:")
        bad_ip_api_results = pd.DataFrame()
        api_results_df = get_all_ip_scores
        # .split(":,:")
        bad_ip_api_keys_string = configvars.data['BAD_IP_API_KEY']
        get_ioc_list = get_all_ip_scores['IP_Address'].to_list()
        for ioc_value in get_ioc_list:
            # time.sleep(10)
            bad_ip_api_results = bad_ip_api_results.append(
                get_ioc_from_bad_ip_db(bad_ip_api_keys_string, ioc_value), ignore_index=True)
        if not bad_ip_api_results.empty:
            # find elements in api_results_df that are not in bad_ip_api_results
            unfetched_iocs = api_results_df[~(api_results_df['IP_Address'].isin(
                bad_ip_api_results['IP_Address']))].reset_index(drop=True)

            for row in unfetched_iocs.itertuples(index=True, name='Pandas'):
                missed_ioc = pd.DataFrame()
                missed_ioc['IP_Address'] = [row[1]]
                # missed_ioc['bad_ip_Remarks'] = [
                #     "Unable to fetch IOC Score's from bad_ip DB by YSOC Intellisense Tool."]
                bad_ip_api_results = bad_ip_api_results.append(
                    missed_ioc, ignore_index=True)

            # print(bad_ip_api_results)
        print("\n Bad IP Report End:")

        return bad_ip_api_results
    except Exception as e:
        logger.error(
            "Got error in bad_ip_db_wrapper function with error:%s.", e)
