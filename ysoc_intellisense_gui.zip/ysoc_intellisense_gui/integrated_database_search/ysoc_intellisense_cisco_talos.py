
from ysoc_intellisense_imports import configvars, pd, requests, logger, time, IndicatorTypes, json


def get_ioc_from_cisco_talo_db(cisco_talo_api_keys_string, get_ip_scores):
    try:
        cisco_talo_api_response_df = pd.DataFrame()

        def iterate_by_api_key(api_key):
            try:
                api_response_df = pd.DataFrame()
                """
                Download data from talosintelligence.com for the given IP

                Return tabbed data text
                """
                r_details = requests.get('https://talosintelligence.com/sb_api/query_lookup',
                                         headers={
                                             'Referer': 'https://talosintelligence.com/reputation_center/lookup?search=%s' % get_ip_scores,
                                             'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:64.0) Gecko/20100101 Firefox/64.0'
                                         },
                                         params={
                                             'query': '/api/v2/details/ip/',
                                             'query_entry': get_ip_scores
                                         })  # .json()

                r_wscore = requests.get('https://talosintelligence.com/sb_api/remote_lookup',
                                        headers={
                                            'Referer': 'https://talosintelligence.com/reputation_center/lookup?search=%s' % get_ip_scores,
                                            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:64.0) Gecko/20100101 Firefox/64.0'
                                        },
                                        params={'hostname': 'SDS', 'query_string': '/score/wbrs/json?url=%s' % get_ip_scores}).json()

                r_talos_blacklist = requests.get('https://www.talosintelligence.com/sb_api/blacklist_lookup',
                                                 headers={
                                                     'Referer': 'https://talosintelligence.com/reputation_center/lookup?search=%s' % get_ip_scores,
                                                     'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:64.0) Gecko/20100101 Firefox/64.0'
                                                 },
                                                 params={'query_type': 'ipaddr', 'query_entry': get_ip_scores}).json()

                talos_blacklisted = {'status': False}
                if 'classifications' in r_talos_blacklist['entry']:
                    talos_blacklisted['status'] = True
                    talos_blacklisted['classifications'] = ", ".join(
                        r_talos_blacklist['entry']['classifications'])
                    talos_blacklisted['first_seen'] = r_talos_blacklist['entry']['first_seen'] + "UTC"
                    talos_blacklisted['expiration'] = r_talos_blacklist['entry']['expiration'] + "UTC"

                data = {
                    'address': get_ip_scores,
                    'hostname': r_details['hostname'] if 'hostname' in r_details else "nodata",
                    'volume_change': r_details['daychange'] if 'daychange' in r_details else "nodata",
                    'lastday_volume': r_details['daily_mag'] if 'daily_mag' in r_details else "nodata",
                    'month_volume': r_details['monthly_mag'] if 'monthly_mag' in r_details else "nodata",
                    'email_reputation': r_details['email_score_name'] if 'email_score_name' in r_details else "nodata",
                    'web_reputation': r_details['web_score_name'] if 'web_score_name' in r_details else "nodata",
                    'weighted_reputation_score': r_wscore['response'],
                    'talos_blacklisted': "Yes" if talos_blacklisted['status'] else "No"
                    # 'weighted_reputation_score':r_wscore[0]['response']['wbrs']['score'],
                    # 'volumes':zip(*r_volume['data'])
                }

                api_response_df['IP_Address'] = [get_ip_scores]
                api_response_df['Cisco_Talo_No_of_Detection_Engines'] = [str(
                    data['data']['report']['blacklists']['engines'])]
                api_response_df['Cisco_Talo_Is_Tor'] = [str(
                    data['data']['report']['anonymity']['is_tor'])]
                api_response_df['Cisco_Talo_Risk_Score'] = [str(
                    data['data']['report']['risk_score']['result'])]
                api_response_df['Cisco_Talo_Remarks'] = ["None."]

                return api_response_df
                # except Exception as e:
                #     api_response_df['Cisco_Talo_Remarks'] = [e]
                #     logger.exception(
                #         "Error unpacking response from Cisco Talos:"+e)

            except Exception as e:
                logger.error(
                    'Error at iterate_by_api_key function while connecting to Cisco Talos database : %s.' , e)
                api_response_df['Cisco_Talo_Remarks'] = [e]

        cisco_talo_api_keys_list = cisco_talo_api_keys_string.split(":,:")

        cisco_talo_api_response_df = iterate_by_api_key(
            cisco_talo_api_keys_list[0])

        while cisco_talo_api_response_df.empty:
            cisco_talo_api_keys = iter(cisco_talo_api_keys_list)
            cisco_talo_api_key = next(cisco_talo_api_keys)
            if cisco_talo_api_key == cisco_talo_api_keys_list[-1:][0]:
                cisco_talo_api_response_df = iterate_by_api_key(
                    cisco_talo_api_keys_list[-1:][0])
                if cisco_talo_api_response_df.empty:
                    cisco_talo_api_response_df['IP_Address'] = [
                        get_ip_scores]
                    cisco_talo_api_response_df['Cisco_Talo_Remarks'] = [
                        "Unable to fetch IOC Score's with available API Key's."]
            else:
                cisco_talo_api_response_df = iterate_by_api_key(
                    cisco_talo_api_key)
        return cisco_talo_api_response_df
    except Exception as e:
        logger.error(
            "Got error in get_ioc_from_cisco_talo_db function with error:%s.", e)


def cisco_talo_db_wrapper(get_all_ip_scores):
    try:
        print("\n IP Cisco Talos Report Start:")
        cisco_talo_api_results = pd.DataFrame()
        api_results_df = get_all_ip_scores
        # .split(":,:")
        cisco_talo_api_keys_string = configvars.data['CISCO_TALOS_API_KEY']
        get_ioc_list = get_all_ip_scores['IP_Address'].to_list()
        for ioc_value in get_ioc_list:
            # time.sleep(2)
            cisco_talo_api_results = cisco_talo_api_results.append(
                get_ioc_from_cisco_talo_db(cisco_talo_api_keys_string, ioc_value), ignore_index=True)
        if not cisco_talo_api_results.empty:
            # find elements in api_results_df that are not in cisco_talo_api_results
            unfetched_iocs = api_results_df[~(api_results_df['IP_Address'].isin(
                cisco_talo_api_results['IP_Address']))].reset_index(drop=True)

            for row in unfetched_iocs.itertuples(index=True, name='Pandas'):
                missed_ioc = pd.DataFrame()
                missed_ioc['IP_Address'] = [row[1]]
                missed_ioc['Cisco_Talo_Remarks'] = [
                    "Unable to fetch IOC Score's from Cisco Talos DB by YSOC Intellisense Tool."]
                cisco_talo_api_results = cisco_talo_api_results.append(
                    missed_ioc, ignore_index=True)

            # print(cisco_talo_api_results)
            print("\n Cisco Talos Report End:")

        return cisco_talo_api_results
    except Exception as e:
        logger.error(
            "Got error in cisco_talo_db_wrapper function with error:%s.", e)
