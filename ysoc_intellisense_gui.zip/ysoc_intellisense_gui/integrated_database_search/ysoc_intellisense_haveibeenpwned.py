
from ysoc_intellisense_imports import configvars, pd, requests, logger, time


def get_ioc_from_hibp_db(hibp_api_keys_string, get_ip_scores):
    try:
        hibp_api_response_df = pd.DataFrame()

        def iterate_by_api_key(api_key):
            try:
                api_response_df = pd.DataFrame()
                url = 'https://haveibeenpwned.com/api/v3/{service}/{parameter}'
                params = {'apikey': api_key, 'resource': get_ip_scores}
                response = requests.get(url, params=params)
                # pos = 0  # Total positives found in VT
                # tot = 0  # Total number of scans
                if response.status_code == 200:
                    try:
                        result = response.json()
                        # for each in result:
                        #     tot = result['total']
                        #     if result['positives'] != 0:
                        #         pos = pos + 1
                        tot = result['total']
                        pos = result['positives']
                        avg = pos/tot
                        # avg = result['positives']/result['total']
                        api_response_df['IP_Address'] = [get_ip_scores]
                        api_response_df['HaveIBeenPwned_No_of_Databases_Checked'] = [
                            tot]
                        api_response_df['HaveIBeenPwned_No_of_Reportings'] = [
                            pos]
                        api_response_df['HaveIBeenPwned_Average_Score'] = [avg]
                        api_response_df['HaveIBeenPwned_Report_Link'] = [
                            result['permalink']]
                        api_response_df['HaveIBeenPwned_Remarks'] = ["None."]

                        return api_response_df
                    except Exception as e:
                        api_response_df['HaveIBeenPwned_Remarks'] = [e]
                        logger.exception(
                            "Error unpacking response from HaveIBeenPwned:%s",e)

            except Exception as e:
                logger.error(
                    'Error at iterate_by_api_key function while connecting to HaveIBeenPwned database : %s' , e)
                api_response_df['HaveIBeenPwned_Remarks'] = [e]

        hibp_api_keys_list = hibp_api_keys_string.split(":,:")

        hibp_api_response_df = iterate_by_api_key(hibp_api_keys_list[0])

        while hibp_api_response_df.empty:
            hibp_api_keys = iter(hibp_api_keys_list)
            hibp_api_key = next(hibp_api_keys)
            if hibp_api_key == hibp_api_keys_list[-1:][0]:
                hibp_api_response_df = iterate_by_api_key(
                    hibp_api_keys_list[-1:][0])
                if hibp_api_response_df.empty:
                    hibp_api_response_df['IP_Address'] = [
                        get_ip_scores]
                    hibp_api_response_df['HaveIBeenPwned_Remarks'] = [
                        "Unable to fetch IOC Score's with available API Key's."]
            else:
                hibp_api_response_df = iterate_by_api_key(hibp_api_key)
        return hibp_api_response_df
    except Exception as e:
        logger.error(
            "Got error in get_ioc_from_hibp_db function with error:%s.", e)


def hibp_db_wrapper(get_all_ip_scores):
    try:
        print("\n HaveIBeenPwned Report Start:")
        hibp_api_results = pd.DataFrame()
        api_results_df = get_all_ip_scores
        hibp_api_keys_string = configvars.data['HIBP_API_KEY']  # .split(":,:")
        get_ioc_list = get_all_ip_scores['IP_Address'].to_list()
        for ioc_value in get_ioc_list:
            # time.sleep(2)
            hibp_api_results = hibp_api_results.append(
                get_ioc_from_hibp_db(hibp_api_keys_string, ioc_value), ignore_index=True)
        if not hibp_api_results.empty:
            # find elements in api_results_df that are not in hibp_api_results
            unfetched_iocs = api_results_df[~(api_results_df['IP_Address'].isin(
                hibp_api_results['IP_Address']))].reset_index(drop=True)

            for row in unfetched_iocs.itertuples(index=True, name='Pandas'):
                missed_ioc = pd.DataFrame()
                missed_ioc['IP_Address'] = [row[1]]
                # missed_ioc['hibp_Remarks'] = [
                #     "Unable to fetch IOC Score's from hibp DB by YSOC Intellisense Tool."]
                hibp_api_results = hibp_api_results.append(
                    missed_ioc, ignore_index=True)

            # print(hibp_api_results)
        print("\n HaveIBeenPwned Report End:")

        return hibp_api_results
    except Exception as e:
        logger.error(
            "Got error in hibp_db_wrapper function with error:%s.", e)
