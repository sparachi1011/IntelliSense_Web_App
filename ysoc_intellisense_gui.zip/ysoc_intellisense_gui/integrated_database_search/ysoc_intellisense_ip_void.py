
from ysoc_intellisense_imports import configvars, pd, requests, logger, time, IndicatorTypes, json


def get_ioc_from_ip_void_db(ip_void_api_keys_string, get_ip_scores):
    try:
        ip_void_api_response_df = pd.DataFrame()

        def iterate_by_api_key(api_key):
            try:
                api_response_df = pd.DataFrame()
                ip_void_server = 'https://endpoint.apivoid.com/iprep/v1/pay-as-you-go/?key=' + \
                    str(api_key)+'&ip='+str(get_ip_scores)
                response = requests.get(url=ip_void_server)

                if response.status_code == 200:
                    try:
                        data = json.loads(response.content.decode())
                        # for each in result:
                        #     tot = result['total']
                        #     if result['positives'] != 0:
                        #         pos = pos + 1

                        def get_detection_engines(engines):
                            engines_list = ""
                            for key, value in engines.items():
                                if (bool(value['detected']) == 1):
                                    engines_list += str(value['engine'])+", "
                            return engines_list.rstrip(", ")

                        if (data):
                            # if (data.get('error')):
                            #     print("Error: "+data['error'])
                            # else:
                            #     print("IP: "+data['data']['report']['ip'])
                            #     print(
                            #         "Hostname: "+data['data']['report']['information']['reverse_dns'])
                            #     print("---")
                            #     print(
                            #         "Detections Count: "+str(data['data']['report']['blacklists']['detections']))
                            #     print(
                            #         "Detected By: "+get_detection_engines(data['data']['report']['blacklists']['engines']))
                            #     print("---")
                            #     print("Country: "+data['data']['report']['information']['country_code'] +
                            #           " ("+data['data']['report']['information']['country_name']+")")
                            #     print("Continent: "+data['data']['report']['information']['continent_code'] +
                            #           " ("+data['data']['report']['information']['continent_name']+")")
                            #     print(
                            #         "Region: "+data['data']['report']['information']['region_name'])
                            #     print(
                            #         "City: "+data['data']['report']['information']['city_name'])
                            #     print(
                            #         "Latitude: "+str(data['data']['report']['information']['latitude']))
                            #     print(
                            #         "Longitude: "+str(data['data']['report']['information']['longitude']))
                            #     print(
                            #         "ISP: "+data['data']['report']['information']['isp'])
                            #     print("---")
                            #     print(
                            #         "Is Proxy: "+str(data['data']['report']['anonymity']['is_proxy']))
                            #     print(
                            #         "Is Web Proxy: "+str(data['data']['report']['anonymity']['is_webproxy']))
                            #     print(
                            #         "Is VPN: "+str(data['data']['report']['anonymity']['is_vpn']))
                            #     print(
                            #         "Is Hosting: "+str(data['data']['report']['anonymity']['is_hosting']))
                            #     print(
                            #         "Is Tor: "+str(data['data']['report']['anonymity']['is_tor']))

                            # tot = data['data']['report']['blacklists']['engines']
                            # pos = data['data']['report']['blacklists']['detections']
                            # avg = pos/tot

                            api_response_df['IP_Address'] = [get_ip_scores]
                            api_response_df['IP_Void_No_of_Detection_Engines'] = [str(
                                get_detection_engines(data['data']['report']['blacklists']['engines']))]
                            api_response_df['IP_Void_Is_Tor'] = [str(
                                data['data']['report']['anonymity']['is_tor'])]
                            api_response_df['IP_Void_Risk_Score'] = [str(
                                data['data']['report']['risk_score']['result'])]
                            api_response_df['IP_Void_Remarks'] = ["None."]

                        return api_response_df
                    except Exception as e:
                        api_response_df['IP_Void_Remarks'] = [e]
                        logger.exception(
                            "Error unpacking response from IP Void:%s",e)

            except Exception as e:
                logger.error(
                    'Error at iterate_by_api_key function while connecting to IP Void database : %s' , e)
                api_response_df['IP_Void_Remarks'] = [e]

        ip_void_api_keys_list = ip_void_api_keys_string.split(":,:")

        ip_void_api_response_df = iterate_by_api_key(ip_void_api_keys_list[0])

        while ip_void_api_response_df.empty:
            ip_void_api_keys = iter(ip_void_api_keys_list)
            ip_void_api_key = next(ip_void_api_keys)
            if ip_void_api_key == ip_void_api_keys_list[-1:][0]:
                ip_void_api_response_df = iterate_by_api_key(
                    ip_void_api_keys_list[-1:][0])
                if ip_void_api_response_df.empty:
                    ip_void_api_response_df['IP_Address'] = [
                        get_ip_scores]
                    ip_void_api_response_df['IP_Void_Remarks'] = [
                        "Unable to fetch IOC Score's with available API Key's."]
            else:
                ip_void_api_response_df = iterate_by_api_key(ip_void_api_key)
        return ip_void_api_response_df
    except Exception as e:
        logger.error(
            "Got error in get_ioc_from_ip_void_db function with error:%s.", e)


def ip_void_db_wrapper(get_all_ip_scores):
    try:
        print("\n IP Void Report Start:")
        ip_void_api_results = pd.DataFrame()
        api_results_df = get_all_ip_scores
        # .split(":,:")
        ip_void_api_keys_string = configvars.data['IP_VOID_API_KEY']
        get_ioc_list = get_all_ip_scores['IP_Address'].to_list()
        for ioc_value in get_ioc_list:
            # time.sleep(2)
            ip_void_api_results = ip_void_api_results.append(
                get_ioc_from_ip_void_db(ip_void_api_keys_string, ioc_value), ignore_index=True)
        if not ip_void_api_results.empty:
            # find elements in api_results_df that are not in ip_void_api_results
            unfetched_iocs = api_results_df[~(api_results_df['IP_Address'].isin(
                ip_void_api_results['IP_Address']))].reset_index(drop=True)

            for row in unfetched_iocs.itertuples(index=True, name='Pandas'):
                missed_ioc = pd.DataFrame()
                missed_ioc['IP_Address'] = [row[1]]
                missed_ioc['IP_Void_Remarks'] = [
                    "Unable to fetch IOC Score's from IP Void DB by YSOC Intellisense Tool."]
                ip_void_api_results = ip_void_api_results.append(
                    missed_ioc, ignore_index=True)

            # print(ip_void_api_results)
        print("\n IP Void Report End:")

        return ip_void_api_results
    except Exception as e:
        logger.error(
            "Got error in ip_void_db_wrapper function with error:%s.", e)
