
from ysoc_intellisense_imports import configvars, pd, requests, logger, time, dt
import hashlib


def get_ioc_from_my_ips_db(my_ips_api_keys_string, get_ip_scores):
    try:
        my_ips_api_response_df = pd.DataFrame()

        def api_url_prep(api_key):
            try:
                api_creds = api_key.split(":-:")
                gm_time = time.gmtime()
                if len(str(gm_time.tm_mon)) == 1:
                    tm_month = "0" + str(gm_time.tm_mon)
                else:
                    tm_month = str(gm_time.tm_mon)

                if len(str(gm_time.tm_mday)) == 1:
                    tm_day = "0" + str(gm_time.tm_mday)
                else:
                    tm_day = str(gm_time.tm_mday)

                if len(str(gm_time.tm_hour)) == 1:
                    tm_hr = "0" + str(gm_time.tm_hour)
                else:
                    tm_hr = str(gm_time.tm_hour)

                if len(str(gm_time.tm_min)) == 1:
                    tm_mn = "0" + str(gm_time.tm_min)
                else:
                    tm_mn = str(gm_time.tm_min)

                if len(str(gm_time.tm_sec)) == 1:
                    tm_sc = "0" + str(gm_time.tm_sec)
                else:
                    tm_sc = str(gm_time.tm_sec)

                time_stamp = str(gm_time.tm_year) + "-" + tm_month + \
                    "-" + tm_day + "_" + tm_hr + ":" + tm_mn + ":" + tm_sc

                url = 'https://api.myip.ms/' + get_ip_scores + "/" + \
                    'api_id' + "/" + api_creds[0] + \
                    "/" + 'api_key' + "/" + api_creds[1]
                to_be_hashed = str(url + "/timestamp/" +
                                   time_stamp).encode("UTF-8")
                md5_hash = hashlib.md5(to_be_hashed).hexdigest()
                final_api_url = url + "/signature/" + md5_hash + "/timestamp/" + time_stamp

                return final_api_url
            except Exception as e:
                logger.exception(
                    "Error in api_url_prep function :"+e)

        def iterate_by_api_key(api_key):
            try:
                api_response_df = pd.DataFrame()
                final_api_url = api_url_prep(api_key)
                response = requests.get(url=final_api_url)
                if response.status_code == 200:
                    result = response.json()
                    api_response_df['IP_Address'] = [get_ip_scores]
                    api_response_df['My_IPs_Owner_Name'] = [
                        result['owners']['owner']['ownerName']]
                    # api_response_df['My_IPs_Last_Reported'] = [timeReport]
                    api_response_df['My_IPs_Remarks'] = ["None."]

                return api_response_df
            except Exception as e:
                api_response_df['My_IPs_Remarks'] = [e]
                logger.exception(
                    "Error unpacking response from Bad IP :%s",e)

            # except Exception as e:
            #     logger.error(
            #         'Error at iterate_by_api_key function while connecting to Bad IP database : ' + e)

        my_ips_api_keys_list = my_ips_api_keys_string.split(":,:")

        my_ips_api_response_df = iterate_by_api_key(my_ips_api_keys_list[0])

        while my_ips_api_response_df.empty:
            my_ips_api_keys = iter(my_ips_api_keys_list)
            my_ips_api_key = next(my_ips_api_keys)
            if my_ips_api_key == my_ips_api_keys_list[-1:][0]:
                my_ips_api_response_df = iterate_by_api_key(
                    my_ips_api_keys_list[-1:][0])
                if my_ips_api_response_df.empty:
                    my_ips_api_response_df['IP_Address'] = [
                        get_ip_scores]
                    my_ips_api_response_df['My_IPs_Remarks'] = [
                        "Unable to fetch IOC Score's with available API Key's."]
            else:
                my_ips_api_response_df = iterate_by_api_key(my_ips_api_key)
        return my_ips_api_response_df
    except Exception as e:
        logger.error(
            "Got error in get_ioc_from_my_ips_db function with error:%s.", e)


def my_ips_db_wrapper(get_all_ip_scores):
    try:
        print("\n Bad IP Report Start:")
        my_ips_api_results = pd.DataFrame()
        api_results_df = get_all_ip_scores
        # .split(":,:")
        my_ips_api_keys_string = configvars.data['MY_IPS_API_KEY']
        get_ioc_list = get_all_ip_scores['IP_Address'].to_list()
        for ioc_value in get_ioc_list:
            # time.sleep(60)
            my_ips_api_results = my_ips_api_results.append(
                get_ioc_from_my_ips_db(my_ips_api_keys_string, ioc_value), ignore_index=True)
        if not my_ips_api_results.empty:
            # find elements in api_results_df that are not in my_ips_api_results
            unfetched_iocs = api_results_df[~(api_results_df['IP_Address'].isin(
                my_ips_api_results['IP_Address']))].reset_index(drop=True)

            for row in unfetched_iocs.itertuples(index=True, name='Pandas'):
                missed_ioc = pd.DataFrame()
                missed_ioc['IP_Address'] = [row[1]]
                # missed_ioc['my_ips_Remarks'] = [
                #     "Unable to fetch IOC Score's from my_ips DB by YSOC Intellisense Tool."]
                my_ips_api_results = my_ips_api_results.append(
                    missed_ioc, ignore_index=True)

            # print(my_ips_api_results)
        print("\n My IPs Report End:")

        return my_ips_api_results
    except Exception as e:
        logger.error(
            "Got error in my_ips_db_wrapper function with error:%s.", e)
