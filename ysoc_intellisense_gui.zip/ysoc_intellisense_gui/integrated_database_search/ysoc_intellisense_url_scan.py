
from ysoc_intellisense_imports import configvars, pd, requests, logger, time


def get_ioc_from_url_scan_db(url_scan_api_keys_string, get_ip_scores):
    try:
        url_scan_api_response_df = pd.DataFrame()

        def iterate_by_api_key(api_key):
            try:
                api_response_df = pd.DataFrame()

                url_to_scan = get_ip_scores

                type_prompt = 1
                # type_prompt = str(input(
                #     '\nSet scan visibility to Public? \nType "1" for Public or "2" for Private: '))

                if type_prompt == '1':
                    scan_type = 'public'
                else:
                    scan_type = 'private'

                headers = {
                    'Content-Type': 'application/json',
                    'API-Key': api_key,
                }

                response = requests.post('https://urlscan.io/api/v1/scan/', headers=headers,
                                         data='{"url": "%s", "%s": "on"}' % (url_to_scan, scan_type)).json()

                if response.status_code == 200:
                    try:
                        result = response.json()
                        # for each in result:
                        #     tot = result['total']
                        #     if result['positives'] != 0:
                        #         pos = pos + 1
                        tot = result['total']
                        pos = result['positives']
                        avg = pos/tot
                        # avg = result['positives']/result['total']
                        api_response_df['IP_Address'] = [get_ip_scores]
                        api_response_df['url_scan_No_of_Databases_Checked'] = [
                            tot]
                        api_response_df['url_scan_No_of_Reportings'] = [pos]
                        api_response_df['url_scan_Average_Score'] = [avg]
                        api_response_df['url_scan_Report_Link'] = [
                            result['permalink']]
                        api_response_df['url_scan_Remarks'] = ["None."]

                        return api_response_df
                    except Exception as e:
                        api_response_df['url_scan_Remarks'] = [e]
                        logger.exception(
                            "Error unpacking response from URL Scan:%s",e)

            except Exception as e:
                logger.error(
                    'Error at iterate_by_api_key function while connecting to URL Scan database : %s' , e)
                api_response_df['url_scan_Remarks'] = [e]

        url_scan_api_keys_list = url_scan_api_keys_string.split(":,:")

        url_scan_api_response_df = iterate_by_api_key(
            url_scan_api_keys_list[0])

        while url_scan_api_response_df.empty:
            url_scan_api_keys = iter(url_scan_api_keys_list)
            url_scan_api_key = next(url_scan_api_keys)
            if url_scan_api_key == url_scan_api_keys_list[-1:][0]:
                url_scan_api_response_df = iterate_by_api_key(
                    url_scan_api_keys_list[-1:][0])
                if url_scan_api_response_df.empty:
                    url_scan_api_response_df['IP_Address'] = [
                        get_ip_scores]
                    url_scan_api_response_df['url_scan_Remarks'] = [
                        "Unable to fetch IOC Score's with available API Key's."]
            else:
                url_scan_api_response_df = iterate_by_api_key(url_scan_api_key)
        return url_scan_api_response_df
    except Exception as e:
        logger.error(
            "Got error in get_ioc_from_url_scan_db function with error:%s.", e)


def url_scan_db_wrapper(get_all_ip_scores):
    try:
        print("\n URL Scan Report Start:")
        url_scan_api_results = pd.DataFrame()
        api_results_df = get_all_ip_scores
        # .split(":,:")
        url_scan_api_keys_string = configvars.data['URLSCAN_IO_KEY']
        get_ioc_list = get_all_ip_scores['IP_Address'].to_list()
        for ioc_value in get_ioc_list:
            # time.sleep(10)
            url_scan_api_results = url_scan_api_results.append(
                get_ioc_from_url_scan_db(url_scan_api_keys_string, ioc_value), ignore_index=True)
        if not url_scan_api_results.empty:
            # find elements in api_results_df that are not in url_scan_api_results
            unfetched_iocs = api_results_df[~(api_results_df['IP_Address'].isin(
                url_scan_api_results['IP_Address']))].reset_index(drop=True)

            for row in unfetched_iocs.itertuples(index=True, name='Pandas'):
                missed_ioc = pd.DataFrame()
                missed_ioc['IP_Address'] = [row[1]]
                # missed_ioc['url_scan_Remarks'] = [
                #     "Unable to fetch IOC Score's from url_scan DB by YSOC Intellisense Tool."]
                url_scan_api_results = url_scan_api_results.append(
                    missed_ioc, ignore_index=True)

            # print(url_scan_api_results)
        print("\n URL Scan Report End:")

        return url_scan_api_results
    except Exception as e:
        logger.error(
            "Got error in url_scan_db_wrapper function with error:%s.", e)
