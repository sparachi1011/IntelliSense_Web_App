
from ysoc_intellisense_imports import configvars, pd, requests, logger, time, pdb


def get_report_from_virus_total_db(vt_api_keys_string, get_ip_scores, report_input):
    try:
        virus_total_api_response_df = pd.DataFrame()
        # pdb.set_trace()
        def iterate_by_api_key(api_key):
            # params = {'apikey': api_key, 'resource': get_ip_scores}
            headers = {'accept': 'application/json', 'x-apikey': str(api_key)}            
            try:
                # pdb.set_trace()
                api_response_df = pd.DataFrame()
                # url = 'https://www.virustotal.com/vtapi/v2/url/report'
                if report_input == 'IP_Address':
                    url = "https://www.virustotal.com/api/v3/ip_addresses/"
                    # params = {'apikey': api_key, 'resource': get_ip_scores}
                    # headers = {'accept': 'application/json', 'x-apikey': str(api_key)}
                    # url = f'{url}{get_ip_scores}'
                    # response = requests.get(url,  headers=headers,verify=False)
                elif report_input == 'HASH_Output':
                    url = "https://www.virustotal.com/api/v3/files/"
                    # params = {'apikey': api_key, 'resource': get_ip_scores}
                    # headers = {'accept': 'application/json', 'x-apikey': str(api_key)}
                    # url = f'{url}{get_ip_scores}'
                    # response = requests.get(url,  headers=headers,verify=False) 
                elif report_input == 'URL_Output':    
                    url = "https://www.virustotal.com/api/v3/domains/"
                    # params = {'apikey': api_key, 'resource': get_ip_scores}
                    # headers = {'accept': 'application/json', 'x-apikey': str(api_key)}
                    # get_ip_scores = base64.urlsafe_b64encode(get_ip_scores.encode()).decode().strip("=")
                    # url = f'{url}{get_ip_scores}'
                    # response = requests.get(url,  headers=headers,verify=False)  #https://www.virustotal.com/gui/home/url
                    
                    
                url = f'{url}{get_ip_scores}'
                response = requests.get(url,  headers=headers,verify=False)
                # print("\n VT Response::\n",response,"\n")
                # pos = 0  # Total positives found in VT
                # tot = 0  # Total number of scans
                if response.status_code == 200:
                    try:
                        result = response.json()  #add the conditions wrt to Indipendent applcations
                        # if report_input == 'IP_Address':
                            # for each in result:
                            #     tot = result['total']
                            #     if result['positives'] != 0:
                            #         pos = pos + 1
                        reputation = result['data']['attributes']['last_analysis_stats']
                        tot = sum(reputation.values())  # result['total']
                        # result['positives']
                        pos = reputation.get('malicious', 0)
                        avg = pos/tot
                        # avg = result['positives']/result['total']
                        # reputation = result['data']['attributes']['last_analysis_stats']
                        # malicious_vendors = reputation.get('malicious', 0)
                        # total_vendors = sum(reputation.values())
                        api_response_df[report_input] = [get_ip_scores]
                        api_response_df['Virus_Total_No_of_Databases_Checked'] = [
                            tot]
                        api_response_df['Virus_Total_No_of_Reportings'] = [pos]
                        vt_Score = result["data"]["attributes"]["last_analysis_stats"]["malicious"] + result["data"]["attributes"]["last_analysis_stats"]["suspicious"]
                        api_response_df["Virus_Total_Average_Score"] = [vt_Score]
                        try:
                            api_response_df['Virus_Total_Report_Link'] = [
                                result['data']['attributes']['whois']]
                        except Exception as e:
                            api_response_df['Virus_Total_Report_Link'] = ["No Link available at Virus Total"]

                        # result['permalink']]
                        api_response_df['Virus_Total_Remarks'] = ["None."]
                        
                        # elif report_input == 'HASH_Output':
                        #     api_response_df[report_input] = [get_ip_scores]
                        #     api_response_df["Virus_Total_Hash_Id"] = [result["data"]["id"]]
                            
                        #     # api_response_df["Virus_Total_Hash_Link"] = [result["data"]["links"]["self"]]
                        #     # api_response_df["Virus_Total_Sigma_Analysis_Stats"] = [result["data"]["attributes"]["sigma_analysis_stats"]]
                        #     # api_response_df["Virus_Total_Crowdsourced_Description"] = [result["data"]["attributes"]["crowdsourced_yara_results"][0]["description"]]
                        #     # api_response_df["Virus_Total_Sha256"] = [result["data"]["attributes"]["sha256"]]
                        #     # api_response_df["Virus_Total_Crowdsourced_Ids_Stats"] = [result["data"]["attributes"]["crowdsourced_ids_stats"]]
                        #     # api_response_df["Virus_Total_Total_Votes"] = [result["data"]["attributes"]["total_votes"]]
                        #     # api_response_df["Virus_Total_Type_Tag"] = [result["data"]["attributes"]["type_tag"]]
                        #     # api_response_df["Virus_Total_Last_Submission_Date"] = [result["data"]["attributes"]["last_submission_date"]]
                        #     # api_response_df["Virus_Total_Sigma_Analysis_Summary"] = [result["data"]["attributes"]["sigma_analysis_summary"]]
                        #     # api_response_df["Virus_Total_Sandbox_Verdicts"] = [result["data"]["attributes"]["sandbox_verdicts"]]
                        #     # api_response_df["Virus_Total_Reputation"] = [result["data"]["attributes"]["reputation"]]
                        #     # api_response_df["Virus_Total_Sigma_Analysis_Description"] = [result["data"]["attributes"]["sigma_analysis_results"][0]["match_context"][0]["values"]["Description"]]
                        #     # api_response_df["Virus_Total_Sigma_Analysis_Original_Filename"] = [result["data"]["attributes"]["sigma_analysis_results"][0]["match_context"][0]["values"]["OriginalFileName"]]
                        #     # api_response_df["Virus_Total_Sigma_Analysis_Hashes"] = [result["data"]["attributes"]["sigma_analysis_results"][0]["match_context"][0]["values"]["Hashes"]]
                        #     # api_response_df["Virus_Total_Sigma_Analysis_Signature_Status"] = [result["data"]["attributes"]["sigma_analysis_results"][10]["match_context"][0]["values"]["SignatureStatus"]]
                            
                        #     api_response_df["Virus_Total_md5"] = [result["data"]["attributes"]["md5"]]
                        #     api_response_df["Virus_Total_Sha256"] = [result["data"]["attributes"]["sha256"]]
                        #     api_response_df["Virus_Total_Sha1"] = [result["data"]["attributes"]["sha1"]]
                        #     vt_Score = result["data"]["attributes"]["last_analysis_stats"]["malicious"] + result["data"]["attributes"]["last_analysis_stats"]["suspicious"]
                        #     api_response_df["Virus_Total_Average_Score"] = [vt_Score]
                        #     api_response_df["Virus_Total_Remarks"] = ["None."]

                        # elif report_input == 'URL_Output':
                        #     api_response_df[report_input] = [get_ip_scores]
                        #     api_response_df["Virus_Total_Domain_ID"] = [result["data"]["id"]]
                        #     api_response_df["Virus_Total_Domain_Type"] = [result["data"]["type"]]
                        #     # api_response_df["Virus_Total_Total_Votes"] = [result["data"]["attributes"]["total_votes"]]
                        #     api_response_df["Virus_Total_Categories"] = [result["data"]["attributes"]["categories"]]
                        #     api_response_df["Virus_Total_Average_Score"] = [result["data"]["attributes"]["last_analysis_stats"]["malicious"]]
                        #     # api_response_df["Virus_Total_Last_Analysis_Stats"] = [result["data"]["attributes"]["last_analysis_stats"]]
                        #     api_response_df["Virus_Total_Last_Analysis_Results"] = [result["data"]["attributes"]["last_analysis_results"]]
                        #     api_response_df["Virus_Total_Remarks"] = ["None."]

                        return api_response_df
                    except Exception as e:
                        api_response_df['Virus_Total_Remarks'] = [e]
                        logger.exception(
                            "Error unpacking response from Virus Total:%s.",e)

            except Exception as e:
                logger.error(
                    'Error at iterate_by_api_key function while connecting to Virus Total database :%s ' , e)
                api_response_df['Virus_Total_Remarks'] = [e]

        vt_api_keys_list = vt_api_keys_string.split(":,:")

        virus_total_api_response_df = iterate_by_api_key(vt_api_keys_list[0])
        # virus_total_api_response_df = pd.DataFrame()
        while virus_total_api_response_df.empty:
            vt_api_keys = iter(vt_api_keys_list)
            vt_api_key = next(vt_api_keys)
            if vt_api_key == vt_api_keys_list[-1:][0]:
                virus_total_api_response_df = iterate_by_api_key(
                    vt_api_keys_list[-1:][0])
            # vt_api_key = np.random.choice(np.array(vt_api_keys_list))
            # if vt_api_key:
            #     print("VT API Key used for IP: ",get_ip_scores,"to get threat intel score is\n",vt_api_key)
            #     virus_total_api_response_df = iterate_by_api_key(
            #         vt_api_key)
            #     # print(virus_total_api_response_df)
                if virus_total_api_response_df.empty:
                    virus_total_api_response_df[report_input] = [
                        get_ip_scores]
                    virus_total_api_response_df['Virus_Total_Remarks'] = [
                        "Unable to fetch Score's with available API Key's."]
            else:
                virus_total_api_response_df = iterate_by_api_key(vt_api_key)
        return virus_total_api_response_df
    except Exception as e:
        logger.error(
            "Got error in get_report_from_virus_total_db function with error:%s.", e)


def virus_total_db_wrapper(get_all_ip_scores, report_input):
    try:
        # print("\n Virus Total Report Start:")
        # pdb.set_trace()
        virus_total_api_results = pd.DataFrame()
        api_results_df = get_all_ip_scores
        vt_api_keys_string = configvars.data['VT_API_KEY']  # .split(":,:")
        get_report_list = get_all_ip_scores[report_input].to_list()
        for report_value in get_report_list:
            # time.sleep(2)
            virus_total_api_results = virus_total_api_results.append(
                get_report_from_virus_total_db(vt_api_keys_string, report_value, report_input), ignore_index=True)
        if not virus_total_api_results.empty:
            # find elements in api_results_df that are not in virus_total_api_results
            unfetched_reports = api_results_df[~(api_results_df[report_input].isin(
                virus_total_api_results[report_input]))].reset_index(drop=True)

            for row in unfetched_reports.itertuples(index=True, name='Pandas'):
                missed_report = pd.DataFrame()
                missed_report[report_input] = [row[1]]
                # missed_report['virus_total_Remarks'] = [
                #     "Unable to fetch Score's from virus_total DB by YSOC Intellisense Tool."]
                virus_total_api_results = virus_total_api_results.append(
                    missed_report, ignore_index=True)

            # print(virus_total_api_results)
        # print("\n Virus Total Report End:")

        return virus_total_api_results
    except Exception as e:
        logger.error(
            "Got error in virus_total_db_wrapper function with error:%s.", e)
