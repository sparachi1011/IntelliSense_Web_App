from ysoc_intellisense_imports import pd, logger, dt, pdb
from ysoc_intellisense_globals import *
from integrated_database_search.ysoc_intellisense_abuseipdb import abuse_ipdb_wrapper
from integrated_database_search.ysoc_intellisense_virustotal import virus_total_db_wrapper
from integrated_database_search.ysoc_intellisense_otx import otx_db_wrapper
from integrated_database_search.ysoc_intellisense_ip_void import ip_void_db_wrapper
from integrated_database_search.ysoc_intellisense_cisco_talos import cisco_talo_db_wrapper
from integrated_database_search.ysoc_intellisense_bad_ip import bad_ip_db_wrapper
from integrated_database_search.ysoc_intellisense_my_ips import my_ips_db_wrapper
from integrated_database_search.ysoc_intellisense_haveibeenpwned import hibp_db_wrapper
from integrated_database_search.ysoc_intellisense_url_scan import url_scan_db_wrapper


def read_automation_input_file():
    try:
        get_all_ip_scores = pd.read_csv("YSOC_IntelliSense_Inputs.csv")
        return get_all_ip_scores
    except Exception as e:
        logger.error(
            "Got error in read_automation_input_file function with error:%s.", e)


def write_automation_output_file(results):
    try:
        results.to_csv("YSOC_IntelliSense_Output_" +
                       str(dt.datetime.now().strftime("%Y_%m_%d_%H_%M_%S")) + ".csv", index=False)

    except Exception as e:
        logger.error(
            "Got error in write_automation_output_file function with error:%s.", e)


def initialize_threatintel_dbs(requested_report_inputs,report_input):
    try:
        abuse_results = requested_report_inputs
        virus_total_results = requested_report_inputs
        otx_results = requested_report_inputs

        if report_input == 'IP_Address': 
            for col in ysoc_intellisense_threatintel_dbs['ysoc_intellisense_threatintel_dbs_for_IP']['abuse_cols']:
                abuse_results[col] = 99999
            for col in ysoc_intellisense_threatintel_dbs['ysoc_intellisense_threatintel_dbs_for_IP']['vt_cols']:
                virus_total_results[col] = 99999
            for col in ysoc_intellisense_threatintel_dbs['ysoc_intellisense_threatintel_dbs_for_IP']['otx_cols']:
                if col == 'OTX_Verdicts':
                    otx_results[col] = None
                else:
                    otx_results[col] = 99999

            intitialized_dbs = {'abuse_results': abuse_results,
                                    'virus_total_results': virus_total_results,
                                    'otx_results': otx_results
                                    }
                                    
        elif report_input == 'HASH_Output' or report_input == 'URL_Output':
            for col in ysoc_intellisense_threatintel_dbs['ysoc_intellisense_threatintel_dbs_for_hash_url']['vt_cols']:
                virus_total_results[col] = 99999
            for col in ysoc_intellisense_threatintel_dbs['ysoc_intellisense_threatintel_dbs_for_hash_url']['otx_cols']:
                if col == 'OTX_Verdicts':
                    otx_results[col] = None
                else:
                    otx_results[col] = 99999

            intitialized_dbs = {
                                    'virus_total_results': virus_total_results,
                                    'otx_results': otx_results
                                    }



        return intitialized_dbs
    except Exception as e:
        logger.error(
            "Got error in initialize_threatintel_dbs function with error:%s.", e)


def main(requested_report_inputs, report_input):
    try:
        ysoc_intelli_sense_results = pd.DataFrame()
        get_all_ip_scores = requested_report_inputs
        # pdb.set_trace()
        # get_all_ip_scores = get_all_ip_scores.apply(lambda x: x.str.strip() if x.dtype.name == 'object' else x, axis=0)
        intitialized_dbs = initialize_threatintel_dbs(get_all_ip_scores.copy(),report_input)
        
        # print("requested_report_inputs", requested_report_inputs,
        #       "\n", type(requested_report_inputs))
        # get_all_ip_scores = read_automation_input_file()
        
        if report_input == 'IP_Address':
            logger.info("Abuse IPDB Report Start:")
            abuse_results = abuse_ipdb_wrapper(get_all_ip_scores, report_input)
            if not abuse_results.empty:
                ysoc_intelli_sense_results = get_all_ip_scores.merge(
                    abuse_results, how='inner', indicator=False, on=report_input)
            else:
                ysoc_intelli_sense_results = get_all_ip_scores.merge(
                    intitialized_dbs['abuse_results'], how='right', indicator=False, on=report_input)

            logger.info("Abuse IPDB Report End:")

            logger.info("Virus Total Report Start:")
            # pdb.set_trace()
            virus_total_results = virus_total_db_wrapper(get_all_ip_scores, report_input)
            if not virus_total_results.empty:
                # ysoc_intelli_sense_results = virus_total_results
                ysoc_intelli_sense_results = ysoc_intelli_sense_results.merge(
                    virus_total_results, how='outer', indicator=False, on=report_input)
            else:
                ysoc_intelli_sense_results = get_all_ip_scores.merge(
                    intitialized_dbs['virus_total_results'], 
                    how='right', indicator=False, on=report_input)

            logger.info("Virus Total Report End:")

            logger.info("OTX Report Start:")
            # print("OTX Report Start:")
            # pdb.set_trace()
            otx_results = otx_db_wrapper(get_all_ip_scores, report_input)
            if not otx_results.empty:
                # ysoc_intelli_sense_results = otx_results
                ysoc_intelli_sense_results = ysoc_intelli_sense_results.merge(
                    otx_results, how='outer', indicator=False, on=report_input)
            else:
                ysoc_intelli_sense_results = get_all_ip_scores.merge(
                    intitialized_dbs['otx_results'], 
                    how='right', indicator=False, on=report_input)
            # print("OTX Report End:")
            logger.info("OTX Report End:")
        elif report_input == 'HASH_Output' or report_input == 'URL_Output':
            logger.info("Virus Total Report Start:")
            # pdb.set_trace()
            virus_total_results = virus_total_db_wrapper(get_all_ip_scores, report_input)
            if not virus_total_results.empty:
                # ysoc_intelli_sense_results = virus_total_results
                ysoc_intelli_sense_results = get_all_ip_scores.merge(
                    virus_total_results, how='inner', indicator=False, on=report_input)
            else:
                ysoc_intelli_sense_results = get_all_ip_scores.merge(
                    intitialized_dbs['virus_total_results'], 
                    how='right', indicator=False, on=report_input)

            logger.info("Virus Total Report End:")

            logger.info("OTX Report Start:")
            # print("OTX Report Start:")
            # pdb.set_trace()
            otx_results = otx_db_wrapper(get_all_ip_scores, report_input)
            if not otx_results.empty:
                # ysoc_intelli_sense_results = otx_results
                ysoc_intelli_sense_results = ysoc_intelli_sense_results.merge(
                    otx_results, how='outer', indicator=False, on=report_input)
            else:
                ysoc_intelli_sense_results = get_all_ip_scores.merge(
                    intitialized_dbs['otx_results'], 
                    how='right', indicator=False, on=report_input)
            # print("OTX Report End:")
            logger.info("OTX Report End:")            

        # # logger.info("IP Void Report Start:")
        # print("IP Void Report Start:")
        # # pdb.set_trace()
        # ip_void_results = ip_void_db_wrapper(get_all_ip_scores)
        # if not ip_void_results.empty:
        #     ysoc_intelli_sense_results = ysoc_intelli_sense_results.merge(
        #         ip_void_results, how='outer', indicator=False)
        # print("IP Void Report End:")
        # # logger.info("IP Void Report End:")

        # # logger.info("Cisco_Talos Report Start:")
        # print("Cisco_Talos Report Start:")
        # # pdb.set_trace()
        # cisco_talos_results = cisco_talo_db_wrapper(get_all_ip_scores)
        # if not cisco_talos_results.empty:
        #     ysoc_intelli_sense_results = ysoc_intelli_sense_results.merge(
        #         cisco_talos_results, how='outer', indicator=False)
        # print("Cisco_Talos Report End:")
        # # logger.info("Cisco_Talos Report End:")

        # # logger.info("Bad IP Report Start:")
        # print("Bad IP Report Start:")
        # # pdb.set_trace()
        # bad_ip_results = bad_ip_db_wrapper(get_all_ip_scores)
        # if not bad_ip_results.empty:
        #     ysoc_intelli_sense_results = ysoc_intelli_sense_results.merge(
        #         bad_ip_results, how='outer', indicator=False)
        # print("Bad IP Report End:")
        # # logger.info("Bad IP Report End:")

        # # logger.info("My IPs Report Start:")
        # print("My IPs Report Start:")
        # # pdb.set_trace()
        # my_ips_results = my_ips_db_wrapper(get_all_ip_scores)
        # if not my_ips_results.empty:
        #     ysoc_intelli_sense_results = ysoc_intelli_sense_results.merge(
        #         my_ips_results, how='outer', indicator=False)
        # print("My IPs Report End:")
        # logger.info("My IPs Report End:")

        # # logger.info("HaveIBeenPwned Report Start:")
        # print("HaveIBeenPwned Report Start:")
        # # pdb.set_trace()
        # hibp_results = hibp_db_wrapper(get_all_ip_scores)
        # if not hibp_results.empty:
        #     ysoc_intelli_sense_results = ysoc_intelli_sense_results.merge(
        #         hibp_results, how='outer', indicator=False)
        # print("HaveIBeenPwned Report End:")
        # # logger.info("HaveIBeenPwned Report End:")

        # logger.info("URL Scan Report Start:")
        # print("URL Scan Report Start:")
        # # pdb.set_trace()
        # url_scan_results = url_scan_db_wrapper(get_all_ip_scores)
        # if not url_scan_results.empty:
        #     ysoc_intelli_sense_results = ysoc_intelli_sense_results.merge(
        #         url_scan_results, how='outer', indicator=False)
        # print("URL Scan Report End:")
        # logger.info("URL Scan Report End:")

        # write_automation_output_file(ysoc_intelli_sense_results)
        # print("\n YSOC IntelliSense Tool Report End:")
        return ysoc_intelli_sense_results
    except Exception as e:
        logger.error(
            "Got error in main function in ysoc_intellisense_wrapper.py with error:%s.", e)

# if __name__ == "__main__":
#     requested_report_inputs = pd.DataFrame(data=['superyupp.fun'], columns=['URL_Output'])
#     report_input = 'URL_Output'
#     print(main(requested_report_inputs, report_input))
#     process_start = datetime.datetime.now()

#     logger.info(
#         "YSOC_IntelliSense Automation - has been triggerd and current Status is: STARTED. at %s", str(process_start))

# main()
#     process_end = datetime.datetime.now()  # .strftime("%Y-%m-%d %H:%M:%S")
#     process_total_time = process_end - process_start
#     logger.info("YSOC_IntelliSense Automation - has been triggerd and current Status is: COMPLETED. with in %s",
#                 str(process_total_time))

