from django.contrib import admin

# Register your models here.
# from ysoc_intellisense.models import cloud_user_info, cloud_services, draft_request, user_requests, compare_services
# # Register your models here.
# admin.site.register([cloud_user_info, cloud_services,
#                     draft_request, user_requests, compare_services])
