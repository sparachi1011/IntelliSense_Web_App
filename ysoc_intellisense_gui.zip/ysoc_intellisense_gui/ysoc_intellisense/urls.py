from django.urls import path

from ysoc_intellisense import views
from authentication import views as auth_views
urlpatterns = [
    path('', views.user_home, name='user_home'),
    path('home', views.user_home, name='user_home'),
    path('user_home', views.user_home, name='home'),
    path('profile', views.profile, name='profile'),
    # path('signin', auth_views.signin, name='signin')

]

handler400 = 'ysoc_intellisense.views.error_400_view'
handler403 = 'ysoc_intellisense.views.error_403_view'
handler404 = 'ysoc_intellisense.views.error_404_view'
handler500 = 'ysoc_intellisense.views.error_500_view'
