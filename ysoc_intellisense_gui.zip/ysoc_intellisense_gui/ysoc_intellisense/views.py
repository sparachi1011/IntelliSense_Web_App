from ysoc_intellisense_imports import pd, pdb, logger, render, redirect, read_frame, cache_control, login
from django.contrib.auth.models import User
from authentication.models import app_user_info
from generate_ioc_report.models import generate_ioc_report_db
# from generate_hash_report.models import generate_hash_report_db
# from generate_url_report.models import generate_url_report_db

# Create your views here.


def get_user_session(request):
    try:
        # print(request)
        # pdb.set_trace()
        data_com = {"LoggedUser": request.session.get('LoggedUser'),#).capitalize(),
                    "LoggedUserEmainID": request.session.get('LoggedUserEmainID'),
                    "UserLoggedIn": False,
                    "NoDataFound": False,
                    }
        # if str(request.session.get('LoggedUser')).capitalize().strip() !='None':
        #     data_com |={"LoggedUser" :str(request.session.get('LoggedUser')).capitalize().strip(),
        #                 "LoggedUserEmainID": request.session.get('LoggedUserEmainID'),}
        # elif str(request.POST['UserName']).capitalize().strip() !='None':
        #     data_com |={"LoggedUser" :str(request.POST['UserName']).capitalize().strip(),
        #                 # "LoggedUserEmainID": request.session.get('LoggedUserEmainID'),
        #                 }
        # elif str(request.GET['UserName']).capitalize().strip() !='None':
        #     data_com |={"LoggedUser" :str(request.GET['UserName']).capitalize().strip(),
        #                 # "LoggedUserEmainID": request.session.get('LoggedUserEmainID'),
        #                 }

        # pdb.set_trace()
        if request.session.get('LoggedUser') !=None:
            ysoc_intellisense_user_info_qs = app_user_info.objects.all().filter(
                    UserName=data_com['LoggedUser'])
            ysoc_intellisense_user_info_df = read_frame(
                ysoc_intellisense_user_info_qs)
            # print(ysoc_intellisense_user_info_df)
            IsUserLoggedInToApp = ysoc_intellisense_user_info_df['IsUserLoggedInToApp']
            data_com |={"UserLoggedIn" :IsUserLoggedInToApp[0],
                        "ysoc_intellisense_user_info_df" :ysoc_intellisense_user_info_df }
        # print("data_com\n",data_com)
        return data_com
    except Exception as e:
        logger.exception(
            "Error at get_user_session funtion in ysoc_intellisense.views as:", e)


def delete_report_db_entries(data_com):
    try:
        data_to_be_deleted = generate_ioc_report_db.objects.filter(
            UserName=data_com['LoggedUser'])
        data_to_be_deleted.delete()
        # data_to_be_deleted = generate_hash_report_db.objects.filter(
        #     UserName=data_com['LoggedUser'])
        # data_to_be_deleted.delete()
        # data_to_be_deleted = generate_url_report_db.objects.filter(
        #     UserName=data_com['LoggedUser'])
        # data_to_be_deleted.delete()
    except Exception as e:
        logger.exception(
            "Error at delete_report_db_entries funtion in ysoc_intellisense.views as:", e)
# @cache_control(no_cache=True, must_revalidate=True, no_store=True)


def user_home(request):
    try:
        # pdb.set_trace()
        data_com = get_user_session(request)
        if data_com["UserLoggedIn"] and data_com["LoggedUser"] !=None:
            delete_report_db_entries(data_com)
            return render(request, "ysoc_intellisense/user_home.html", data_com)
        else:
            return redirect('signin')
    except Exception as e:
        logger.exception(
            "Error at user_home funtion in ysoc_intellisense.views as:", e)


# @cache_control(no_cache=True, must_revalidate=True, no_store=True)
def home(request):
    try:
        fname = ""
        data_com = get_user_session(request)
        # UserLoggedIn = data_com["UserLoggedIn"]#True
        if data_com["UserLoggedIn"] and data_com["LoggedUser"] !=None:
            return render(request, "ysoc_intellisense/user_home.html",
                           {"FirstName": fname, "UserLoggedIn": data_com["UserLoggedIn"]})
        else:
            return redirect('signin')
    except Exception as e:
        logger.exception(
            "Error at home funtion in ysoc_intellisense.views as:", e)

# @cache_control(no_cache=True, must_revalidate=True, no_store=True)


def profile(request):
    try:
        data_com = get_user_session(request)
        delete_report_db_entries(data_com)
        # pdb.set_trace()
        if data_com["UserLoggedIn"] and data_com["LoggedUser"] !=None:
            if request.method == "GET":

                """Choices are: date_joined, email, first_name, groups, id, is_active, is_staff, 
                is_superuser, last_login, last_name, logentry, password, user_permissions, username"""

                app_user_info_db, user_db = True, False

                # ysoc_intellisense_user_info_qs = app_user_info.objects.all().filter(
                #     UserName=data_com['LoggedUser'])
                # ysoc_intellisense_user_info_df = read_frame(
                #     ysoc_intellisense_user_info_qs)

                # print(ysoc_intellisense_user_info_df)
                if data_com['ysoc_intellisense_user_info_df'].empty:
                    app_user_info_db = False
                    ysoc_intellisense_user_info_qs = User.objects.all().filter(
                        username=data_com['LoggedUser'])
                    data_com |= {"ysoc_intellisense_user_info_df": read_frame(
                        ysoc_intellisense_user_info_qs)}
                    user_db = True
                elif data_com['ysoc_intellisense_user_info_df'].empty:
                    data_com.update({"NoDataFound": True})
                # pdb.set_trace()
                if not data_com["NoDataFound"]:
                    # ysoc_intellisense_user_info_df = ysoc_intellisense_user_info_df.drop(
                    #     ["id"], axis=1)
                    # print("ysoc_intellisense_user_info_df\n",
                    #       ysoc_intellisense_user_info_df.columns)
                    if user_db:
                        rename_columns = {"username": "User_Name",
                                        "first_name": "User_First_Name",
                                        "last_name": "User_Last_Name",
                                        "email": "User_Email",
                                        # "groups": "User_Group",
                                        "is_active": "Is_User_Active",
                                        # "user_permissions": "User_Permissions",
                                        "date_joined": "User_Created_Date",
                                        }
                    elif app_user_info_db:
                        rename_columns = {"UserName": "User_Name",
                                        "FirstName": "User_First_Name",
                                        "LastName": "User_Last_Name",
                                        "EmailID": "User_Email",
                                        # "groups": "User_Group",
                                        "UserAccountActivated": "Is_User_Active",
                                        # "user_permissions": "User_Permissions",
                                        "UserJoinedDate": "User_Created_Date",
                                        }

                    # pdb.set_trace()
                    ysoc_intellisense_user_info_df = data_com['ysoc_intellisense_user_info_df']
                    ysoc_intellisense_user_info_df.rename(
                        columns=rename_columns, inplace=True)
                    ysoc_intellisense_user_info_df = ysoc_intellisense_user_info_df.loc[:, rename_columns.values(
                    )].copy()

                    ysoc_intellisense_user_info_headings = ysoc_intellisense_user_info_df.columns
                    ysoc_intellisense_user_info_df = list(
                        ysoc_intellisense_user_info_df.itertuples(index=False))
                    # print(ysoc_intellisense_user_info_df)
                    data_com.update(
                        {"ysoc_intellisense_user_info_headings":  ysoc_intellisense_user_info_headings})
                    data_com.update(
                        {"ysoc_intellisense_user_info_df":  ysoc_intellisense_user_info_df})

                    # elif request.GET['NewDetailAddition'] == 'True':
                    data_com.update({"DisplayProfileDetails": True})

            # except Exception:
            #     data_com.update({"NoDataFound": True})

            return render(request, "ysoc_intellisense/profile.html", data_com)
        else:
            return redirect('signin')
    except Exception as e:
        logger.exception(
            "Error at profile funtion in ysoc_intellisense.views as:", e)


def error_400_view(request, exception):
    # we add the path to the 400.html file
    # here. The name of our HTML file is 400.html
    return render(request, '400.html')


def error_403_view(request, exception):
    return render(request, '403.html')


def error_404_view(request, exception):
    return render(request, '404.html')


def error_500_view(request):
    return render(request, '500.html')
