EMAIL_USE_TLS = True
EMAIL_HOST = "smtp.office365.com:587"#'smtp.jp.ykgw.net' 'outlook.office365.com'
EMAIL_HOST_USER = "yil-ccc-autoalerts@yokogawa.com"
EMAIL_HOST_PASSWORD = "YKGW@12345"
EMAIL_PORT = 587 #25
